import puppeteer from "puppeteer-core";
const b = await puppeteer.launch({executablePath:"C:/Program Files/Google/Chrome/Application/chrome.exe",headless:"new",args:["--window-size=1440,900"]});
const pg = await b.newPage();
await pg.setViewport({width:1440,height:900});
pg.on("pageerror", e=>console.log("PAGEERROR:",e.message.split("\n")[0]));
await pg.goto("http://localhost:5173",{waitUntil:"networkidle2",timeout:60000});
await new Promise(r=>setTimeout(r,4000));

const at = async (sel,f)=>{
  const y = await pg.evaluate(({sel,f})=>{const r=document.querySelector(sel).getBoundingClientRect();
    return Math.max(0,Math.round(r.top+scrollY-innerHeight+(r.height+innerHeight)*f));},{sel,f});
  await pg.evaluate(y=>scrollTo({top:y,behavior:"instant"}),y);
  await new Promise(r=>setTimeout(r,1600));
  const d = await pg.evaluate(()=>window.__TKL_DEBUG__());
  return {skin:+d.skinPos.toFixed(2), map:+d.mapMix.toFixed(3), 回归:+d.baseReturn.toFixed(2)};
};

// 先滚到延展章节末尾（高定），再逐段向后与向前检查
console.log("延展 75% (星夜附近):", JSON.stringify(await at("#ch-skins",0.75)));
console.log("延展 100% (高定):   ", JSON.stringify(await at("#ch-skins",1)));
console.log("演进 30%:          ", JSON.stringify(await at("#ch-ar",0.30)));
console.log("演进 70%:          ", JSON.stringify(await at("#ch-ar",0.70)));
console.log("后记 50%:          ", JSON.stringify(await at("#ch-end",0.50)));
console.log("-- 回滚检查（梵高是否残留）--");
console.log("画廊 50%:          ", JSON.stringify(await at("#ch-gallery",0.5)));
console.log("近景 50%:          ", JSON.stringify(await at("#ch-dive",0.5)));
console.log("远景 50%:          ", JSON.stringify(await at("#ch-far",0.5)));
console.log("开屏 50%:          ", JSON.stringify(await at("#ch-opening",0.5)));
console.log("开场:              ", JSON.stringify(await at("#ch-hero",0)));
await b.close();
