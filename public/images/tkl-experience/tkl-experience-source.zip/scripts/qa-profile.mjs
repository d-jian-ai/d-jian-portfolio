/**
 * 交界处卡顿归因：在开屏→远景交界前后开 CPU profiler，
 * 按自身耗时聚合函数，直接看出那一帧花在哪。
 */
import puppeteer from "puppeteer-core";

const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const browser = await puppeteer.launch({
  executablePath: EXE,
  headless: "new",
  args: ["--no-sandbox", "--enable-webgl", "--use-gl=angle"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1440, height: 900 });
await page.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await new Promise((r) => setTimeout(r, 4000));

const bounds = await page.evaluate(() => {
  const o = document.getElementById("ch-opening");
  const f = document.getElementById("ch-far");
  return { from: o.offsetTop + o.offsetHeight * 0.82, to: f.offsetTop + f.offsetHeight * 0.15 };
});
await page.evaluate((y) => scrollTo(0, y), bounds.from);
await new Promise((r) => setTimeout(r, 1500));

const client = await page.createCDPSession();
await client.send("Profiler.enable");
await client.send("Profiler.setSamplingInterval", { interval: 100 }); // 100µs，够细
await client.send("Profiler.start");

await page.evaluate(async (b) => {
  let y = b.from;
  const step = (b.to - b.from) / 130;
  await new Promise((done) => {
    const tick = () => {
      y += step;
      scrollTo(0, y);
      if (y < b.to) requestAnimationFrame(tick);
      else done();
    };
    requestAnimationFrame(tick);
  });
}, bounds);

const { profile } = await client.send("Profiler.stop");

// 按自身耗时聚合
const byId = new Map(profile.nodes.map((n) => [n.id, n]));
const self = new Map();
const total = profile.timeDeltas.reduce((a, b) => a + Math.max(0, b), 0);
profile.samples.forEach((id, i) => {
  const dt = Math.max(0, profile.timeDeltas[i] ?? 0);
  const n = byId.get(id);
  if (!n) return;
  const cf = n.callFrame;
  const name = (cf.functionName || "(匿名)") + "  " + (cf.url || "").split("/").pop() + ":" + cf.lineNumber;
  self.set(name, (self.get(name) ?? 0) + dt);
});

const rows = [...self.entries()].sort((a, b) => b[1] - a[1]).slice(0, 18);
console.log(`采样总时长 ${(total / 1000).toFixed(0)}ms，自身耗时前 18 名：\n`);
for (const [name, us] of rows) {
  const ms = us / 1000;
  if (ms < 0.8) continue;
  console.log(`  ${ms.toFixed(1).padStart(7)}ms  ${((ms / (total / 1000)) * 100).toFixed(1).padStart(5)}%  ${name}`);
}
await browser.close();
