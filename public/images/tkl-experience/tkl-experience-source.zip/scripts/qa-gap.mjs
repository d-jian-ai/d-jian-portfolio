import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 1440, height: 900 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await p.evaluate(() => { window.__TKL_NOSNAP__ = true; });
await new Promise(r => setTimeout(r, 3000));
const bounds = await p.evaluate(() => {
  const f = document.getElementById("ch-far"), d = document.getElementById("ch-dive");
  return { a: f.offsetTop + f.offsetHeight * 0.5, b: d.offsetTop + d.offsetHeight * 0.75, vh: innerHeight };
});
const rows = [];
for (let y = bounds.a; y <= bounds.b; y += 90) {
  const s = await p.evaluate(y => {
    scrollTo(0, Math.round(y));
    return new Promise(r => setTimeout(() => {
      const vis = [...document.querySelectorAll(".overlay")]
        .map(o => ({ id: o.dataset.for, op: +getComputedStyle(o).opacity }))
        .filter(o => o.op > 0.02 && o.id !== "ch-end");
      r(vis);
    }, 130));
  }, y);
  rows.push({ y: Math.round(y), vis: s });
}
let run = 0, best = 0, startY = 0, bestStart = 0;
for (const r of rows) {
  if (r.vis.length === 0) { if (run === 0) startY = r.y; run += 90; if (run > best) { best = run; bestStart = startY; } }
  else run = 0;
}
console.log(`视口 ${bounds.vh}px`);
for (const r of rows.filter((_,i)=>i%3===0))
  console.log(`  y=${String(r.y).padStart(6)}  ${r.vis.length ? r.vis.map(v=>`${v.id} ${v.op.toFixed(2)}`).join("  ") : "—— 无 UI ——"}`);
console.log(`\n远景与近景之间的纯画面间歇：${best}px = ${(best/bounds.vh).toFixed(2)} 屏  (y ${bestStart}~${bestStart+best})`);
console.log(best >= bounds.vh * 0.8 ? "✓ 已空出约一屏什么都不显示" : "✗ 间歇不足一屏");
await b.close();
