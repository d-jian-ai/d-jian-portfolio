import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 1440, height: 900 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await new Promise(r => setTimeout(r, 3500));
if (process.env.WARM) { await p.evaluate(() => scrollTo(0, document.body.scrollHeight)); await new Promise(r => setTimeout(r, 6000)); await p.evaluate(() => scrollTo(0, 0)); await new Promise(r => setTimeout(r, 2500)); }
const bounds = await p.evaluate(() => {
  const o = document.getElementById("ch-opening"), f = document.getElementById("ch-far"), d = document.getElementById("ch-dive");
  return { from: o.offsetTop + o.offsetHeight * 0.75, farTop: f.offsetTop, farBot: f.offsetTop + f.offsetHeight, to: d.offsetTop + d.offsetHeight * 0.4 };
});
await p.evaluate(y => scrollTo(0, y), bounds.from);
await new Promise(r => setTimeout(r, 1500));
// 边匀速滚动边记录帧间隔
const res = await p.evaluate(async (b) => {
  const frames = [];
  let y = b.from;
  const step = (b.to - b.from) / 260;
  let last = performance.now();
  await new Promise(done => {
    const tick = () => {
      const now = performance.now();
      frames.push({ y: Math.round(y), ms: +(now - last).toFixed(1) });
      last = now;
      y += step;
      scrollTo(0, y);
      if (y < b.to) requestAnimationFrame(tick); else done();
    };
    requestAnimationFrame(tick);
  });
  return frames;
}, bounds);
const zone = (y) => y < bounds.farTop ? "开屏" : y > bounds.farBot ? "近景" : "远景";
const groups = {};
for (const f of res.slice(5)) (groups[zone(f.y)] ??= []).push(f.ms);
console.log("匀速滚动时的帧间隔（ms）：");
for (const [k, v] of Object.entries(groups)) {
  const avg = v.reduce((a, c) => a + c, 0) / v.length;
  const long = v.filter(x => x > avg * 2.2).length;
  console.log(`  ${k}  平均 ${avg.toFixed(1)}  最长 ${Math.max(...v).toFixed(0)}  卡顿帧 ${long}/${v.length}`);
}
// 边界附近的长帧
const bad = res.slice(5).filter(f => f.ms > 40);
console.log(`\n超过 40ms 的帧共 ${bad.length} 个：`);
for (const f of bad.slice(0, 12)) console.log(`  y=${f.y} (${zone(f.y)})  ${f.ms}ms`);
await b.close();
