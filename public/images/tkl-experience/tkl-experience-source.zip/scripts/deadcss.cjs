/**
 * 死样式扫描：列出 styles.css 里定义了、但 HTML 与 TS 中都没出现过的类名。
 * 类名可能由 JS 拼接产生，所以只作为线索，删之前仍需人工确认。
 */
const fs = require("fs");
const css = fs.readFileSync("src/styles.css", "utf8");
const sources = ["index.html", "src/scroll/chapters.ts", "src/experience/Experience.ts", "src/experience/VoxelCity.ts", "src/main.ts"]
  .map((f) => fs.readFileSync(f, "utf8"))
  .join("\n");

const classes = new Set();
css
  .replace(/\/\*[\s\S]*?\*\//g, "")
  .split("}")
  .forEach((block) => {
    const sel = block.split("{")[0];
    if (!sel || sel.includes("@")) return;
    (sel.match(/\.[A-Za-z][\w-]*/g) || []).forEach((c) => classes.add(c.slice(1)));
  });

const dead = [...classes].filter((c) => !sources.includes(c));
console.log(`样式表共 ${classes.size} 个类，其中 ${dead.length} 个在 HTML/TS 中查无引用：`);
dead.sort().forEach((c) => console.log("  ." + c));
