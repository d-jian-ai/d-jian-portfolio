# 探针与工具

全部用无头 Chrome 驱动真实页面测量，跑之前先 `npm run dev`（端口 5173）。
设计原则是**先测再改**——这个项目里几乎每一次「感觉不对」最后都对应一个能量出来的缺陷。

## 镜头

| 脚本 | 作用 |
| --- | --- |
| `qa-camfull.mjs` | 全片 90 点采样。报每章的**世界位移**与**观感速度**，以及相邻采样的速度断层。<br>观感速度 = 位移 ÷ 机位到目标的距离——同样的位移离主体越近画面动得越快，只看世界位移会把俯冲段误判成「太慢」。 |
| `qa-orbit.mjs` | 把概念/开屏/远景/近景换算成方位角、半径、高度，检查每章是否**只朝一个方向转**、半径不回弹。方位角会先解绕，否则 ±180° 处的跳变会被误报成反向转动。 |
| `qa-layout.mjs` | 各章节占多少屏、全页多长。 |
| `qa-shots.mjs` / `qa-arcshots.mjs` | 定点截图。 |

## 体素城市

| 脚本 | 作用 |
| --- | --- |
| `qa-floatchk.mjs` | 每个悬浮簇的行程与其正下方静止方块的净空——防止浮动时穿模。 |
| `qa-maty.mjs` | 从实例矩阵读回浮动方块的实际 Y，实测幅度。<br>只看 `cluster.offset` 不够：数值在变，不代表矩阵真的写下去了。 |
| `qa-dissolvesync.mjs` | 消散时标牌与方块的消失比例是否同步。 |
| 页面控制台 `__TKL_SIGNS__()` | 各标牌最终挂在哪一格、朝哪一面（世界坐标 + 法线）。调标牌位置时先用它确认当前落点，再反推 `localPosition`。 |
| `qa-skinresidue.mjs` | 换肤与回归基础色时有没有贴图残留。 |

## 交互与性能

| 脚本 | 作用 |
| --- | --- |
| `qa-frametime.mjs` | 匀速滚动时的帧间隔，定位卡顿落在哪一段。 |
| `qa-labeljitter.mjs` | 标签逐帧抖动（二阶差分），亚像素级才算过。 |
| `qa-freeze.mjs` | 结尾自转中点「回到街区上空」：是否就地冻结、是否真的回到顶部。 |
| `qa-snap.mjs` | 滚动吸附：小幅滚动收拢、大幅滚动不受干扰。 |
| `qa-gap.mjs` | 远景与近景之间那一屏「什么都不显示」的间歇有多长。 |
| `qa-mobile.mjs` | 窄屏布局与溢出。<br>注意：浮层是 `position: fixed`，内容被裁掉时**不会**撑开文档——只查 `scrollWidth` 会得到假阴性，必须看截图。 |

## 媒体转码

没有 ffmpeg，全部靠 Chrome 自己的 MediaRecorder / canvas 编码。

```bash
node scripts/gifinfo.cjs public/assets/media/*.gif      # 先读尺寸、帧数、时长
TARGETS='[{"file":"...","seconds":5.96,"w":750,"h":1624,"scale":0.6,"kbps":1500}]' \
  node scripts/transcode.mjs public/assets/media        # GIF → WebM（约小 50~90 倍）
node scripts/vid2webm.mjs 输入.mp4 输出目录 760 1100     # MP4 → WebM
JOBS='[{"file":"...","maxW":520,"q":0.8}]' \
  node scripts/imgshrink.mjs 输出目录                    # PNG/JPG → WebP
node scripts/checkwebm.mjs 某个.webm [截图.jpg]          # 验时长/尺寸/画面
```

`seconds` 要填 GIF 的一个完整循环长度（`gifinfo.cjs` 会给），录多了会接上第二遍。

## 代码卫生

| 脚本 | 作用 |
| --- | --- |
| `deadcss.cjs` | 样式表里定义了但 HTML/TS 中查无引用的类。类名可能由 JS 拼接，删之前仍需确认。 |
| `cleancss.cjs` | 删除只作用于死类的规则，并给选择器列表去重。 |
| `deadexports.cjs` | export 了但没有其它文件引用的符号。`tsc --noUnusedLocals` 查不到这一类。 |
