import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 1440, height: 900 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await p.evaluate(() => { window.__TKL_NOSNAP__ = true; });
await new Promise(r => setTimeout(r, 3000));
await p.evaluate(() => { const e = document.getElementById("ch-far"); scrollTo(0, e.offsetTop + e.offsetHeight * 0.85); });
await new Promise(r => setTimeout(r, 2000));
const track = {};
for (let i = 0; i < 9; i++) {
  const m = await p.evaluate(() => window.__TKL_MATY__());
  for (const [k, v] of Object.entries(m)) (track[k] ??= []).push(v);
  await new Promise(r => setTimeout(r, 1700));
}
console.log("14 秒内各楼首个浮动方块的实例矩阵 Y：");
for (const [k, v] of Object.entries(track)) {
  const amp = Math.max(...v) - Math.min(...v);
  console.log(`  ${k} 号楼  ${v.map(x=>x.toFixed(2)).join(" ")}   实测幅度 ${amp.toFixed(2)}`);
}
await b.close();
