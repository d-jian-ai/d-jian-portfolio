import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const OUT = process.argv[2];
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 1440, height: 900 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await p.evaluate(() => { window.__TKL_NOSNAP__ = true; });
await new Promise(r => setTimeout(r, 3000));
for (const [id, f, name] of [["ch-far",0.45,"远景45"],["ch-far",0.75,"远景75"]]) {
  await p.evaluate((id, f) => { const el = document.getElementById(id); window.scrollTo(0, Math.round(el.offsetTop + el.offsetHeight * f - innerHeight * 0.5)); }, id, f);
  await new Promise(r => setTimeout(r, 2000));
  await p.screenshot({ path: `${OUT}/${name}.jpg`, quality: 78, type: "jpeg" });
}
await b.close();
