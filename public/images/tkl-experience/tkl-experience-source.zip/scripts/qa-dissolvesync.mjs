import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 1440, height: 900 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await p.evaluate(() => { window.__TKL_NOSNAP__ = true; });
await new Promise(r => setTimeout(r, 3200));
// 先滚到远景让标牌浮现，再回到底部
await p.evaluate(() => { const e = document.getElementById("ch-far"); scrollTo(0, e.offsetTop + e.offsetHeight * 0.8); });
await new Promise(r => setTimeout(r, 1500));
const rows = [];
for (const v of [0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1]) {
  rows.push(await p.evaluate(v => window.__TKL_DISSOLVE__(v), v));
  await new Promise(r => setTimeout(r, 90));
}
console.table(rows);
let worst = 0, at = 0;
for (const r of rows) { const d = Math.abs(r.方块已消失 - r.标牌已消失); if (d > worst) { worst = d; at = r.消散度; } }
console.log(worst <= 18 ? `✓ 标牌与方块同步退场（最大偏差 ${worst.toFixed(1)}% @ 消散度 ${at}）`
                        : `✗ 不同步：最大偏差 ${worst.toFixed(1)}% @ 消散度 ${at}`);
await p.evaluate(() => window.__TKL_DISSOLVE__(0));
await b.close();
