import puppeteer from "puppeteer-core";
const b=await puppeteer.launch({executablePath:"C:/Program Files/Google/Chrome/Application/chrome.exe",headless:"new",args:["--window-size=1440,900"]});
const pg=await b.newPage(); await pg.setViewport({width:1440,height:900});
await pg.goto("http://localhost:5173",{waitUntil:"networkidle2",timeout:60000});
await new Promise(r=>setTimeout(r,4500));
const d=await pg.evaluate(()=>{
  const vh=innerHeight, max=document.documentElement.scrollHeight-vh;
  const secs=[...document.querySelectorAll(".chapter")].map(s=>{
    const r=s.getBoundingClientRect();
    return {章节:s.dataset.title||s.id, id:s.id, 高度vh:+(r.height/vh).toFixed(2), 像素:Math.round(r.height)};
  });
  const v=document.querySelector(".video-stage video");
  return {视口高:vh, 全页可滚:Math.round(max), 总屏数:+(max/vh).toFixed(1), 视频时长秒:v?+v.duration.toFixed(1):null, secs};
});
console.log(`视口 ${d.视口高}px | 全页可滚 ${d.全页可滚}px = ${d.总屏数} 屏 | 开屏视频 ${d.视频时长秒}s`);
console.log("章节           高度(屏)   像素");
for(const s of d.secs) console.log(`  ${s.章节.padEnd(6)} ${String(s.高度vh).padStart(8)}   ${String(s.像素).padStart(6)}`);
await b.close();
