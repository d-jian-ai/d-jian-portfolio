/** 极简 GIF 解析：只取尺寸、帧数与总时长（读 Graphic Control Extension 的 delay） */
const fs = require("fs");
function gifInfo(file) {
  const b = fs.readFileSync(file);
  if (b.toString("ascii", 0, 3) !== "GIF") throw new Error("不是 GIF: " + file);
  const w = b.readUInt16LE(6), h = b.readUInt16LE(8);
  let p = 13;
  const flags = b[10];
  if (flags & 0x80) p += 3 * (2 << (flags & 7));   // 全局色表
  let frames = 0, delay = 0;
  while (p < b.length) {
    const c = b[p];
    if (c === 0x21) {                               // 扩展块
      const label = b[p + 1];
      p += 2;
      if (label === 0xf9) { delay += b.readUInt16LE(p + 2); }
      while (p < b.length && b[p] !== 0) p += b[p] + 1;
      p++;
    } else if (c === 0x2c) {                        // 图像描述符
      frames++;
      const lf = b[p + 9];
      p += 10;
      if (lf & 0x80) p += 3 * (2 << (lf & 7));      // 局部色表
      p++;                                          // LZW 最小码长
      while (p < b.length && b[p] !== 0) p += b[p] + 1;
      p++;
    } else break;
  }
  // delay 单位是 1/100 秒；很多录屏工具写 0 或 1，按浏览器规则最小按 10 处理
  const ms = delay * 10 || frames * 100;
  return { w, h, frames, seconds: +(ms / 1000).toFixed(2), mb: +(b.length / 1048576).toFixed(1) };
}
module.exports = gifInfo;
if (require.main === module) for (const f of process.argv.slice(2)) {
  try { console.log(f.split(/[\/]/).pop().padEnd(18), JSON.stringify(gifInfo(f))); }
  catch (e) { console.log(f, "失败:", e.message); }
}
