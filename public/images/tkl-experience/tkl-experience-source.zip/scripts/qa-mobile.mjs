import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const OUT = process.argv[2];
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await new Promise(r => setTimeout(r, 4000));
const info = await p.evaluate(() => ({
  可滚动: document.documentElement.scrollHeight - innerHeight,
  横向溢出: document.documentElement.scrollWidth > innerWidth + 1 ? document.documentElement.scrollWidth - innerWidth : 0,
}));
console.log("移动端 390×844:", JSON.stringify(info));
for (const [id, f, n] of [["ch-context",0.5,"起点"],["ch-far",0.3,"远景"],["ch-gallery",0.3,"界面"]]) {
  await p.evaluate((id,f)=>{const e=document.getElementById(id); scrollTo(0, e.offsetTop+e.offsetHeight*f);}, id, f);
  await new Promise(r => setTimeout(r, 2200));
  const ov = await p.evaluate(() => { const o = [...document.querySelectorAll(".overlay")].find(x=>+getComputedStyle(x).opacity>0.5);
    if (!o) return null; const r = o.getBoundingClientRect();
    const kids = [...o.children].map(c=>{const b=c.getBoundingClientRect();return {w:Math.round(b.width),h:Math.round(b.height),下溢:Math.round(b.bottom-innerHeight)};});
    return { 章节: o.dataset.for, 子块: kids }; });
  console.log(` ${n}:`, JSON.stringify(ov));
  await p.screenshot({ path: `${OUT}/${n}.jpg`, quality: 80, type: "jpeg" });
}
await b.close();
