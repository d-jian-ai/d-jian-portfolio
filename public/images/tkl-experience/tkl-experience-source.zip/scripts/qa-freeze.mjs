import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: Number(process.env.W||1440), height: Number(process.env.H||900) });
p.on("console", m => { if (m.text().includes("回到上空")) console.log("   ", m.text()); });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await new Promise(r => setTimeout(r, 3500));
for (let i = 0; i < 90; i++) { await p.mouse.wheel({ deltaY: 1400 }); await new Promise(r => setTimeout(r, 45)); }
// 停留 6 秒让自转积累明显角度
await new Promise(r => setTimeout(r, 6000));
const cam = () => p.evaluate(() => window.__TKL_DEBUG__().cam.map(v => +v.toFixed(2)));
const a = await cam();
const az = c => +(Math.atan2(c[2], c[0]) * 180 / Math.PI).toFixed(1);
console.log(`视口 ${process.env.W||1440}x${process.env.H||900}`);
console.log("自转 6 秒后机位", a, " 方位角", az(a));
const r = await p.evaluate(() => { const q = document.querySelector("#back-top").getBoundingClientRect(); return [q.left+q.width/2, q.top+q.height/2]; });
await p.mouse.click(r[0], r[1]);
await new Promise(res => setTimeout(res, 120));
const c1 = await cam();
console.log("点击后 120ms  ", c1, " 方位角", az(c1), ` 位移 ${Math.hypot(c1[0]-a[0],c1[1]-a[1],c1[2]-a[2]).toFixed(2)}`);
await new Promise(res => setTimeout(res, 700));
const c2 = await cam();
console.log("点击后 820ms  ", c2, " 方位角", az(c2), ` 相对冻结点位移 ${Math.hypot(c2[0]-c1[0],c2[1]-c1[1],c2[2]-c1[2]).toFixed(2)}`);
const back = Math.abs(az(c2) - az(a));
console.log(back < 1.2 ? `✓ 就地停住：方位角变化仅 ${back.toFixed(2)}°，没有回摆` : `✗ 仍在回摆 ${back.toFixed(1)}°`);
let last = 0;
for (const ms of [2200, 3400, 5000, 7200]) {
  await new Promise(res => setTimeout(res, ms - last)); last = ms;
  const s = await p.evaluate(() => ({ y: Math.round(scrollY), w: document.body.classList.contains("is-warping"), h: +getComputedStyle(document.querySelector(".hero-inner")).opacity }));
  console.log(`  +${String(ms).padStart(4)}ms  scrollY=${String(s.y).padStart(6)}  遮罩=${s.w?"是":"否"}  开场文字=${s.h.toFixed(2)}`);
}
const e = await p.evaluate(() => Math.round(scrollY));
console.log(e < 5 ? `✓ 已回到顶部` : `✗ 失败：停在 ${e}`);
await b.close();
