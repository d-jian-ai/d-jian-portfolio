import puppeteer from "puppeteer-core";
const b = await puppeteer.launch({executablePath:"C:/Program Files/Google/Chrome/Application/chrome.exe",headless:"new",args:["--window-size=1440,900"]});
const pg = await b.newPage();
await pg.setViewport({width:1440,height:900});
pg.on("pageerror", e=>console.log("PAGEERROR:",e.message.split("\n")[0]));
await pg.goto("http://localhost:5173",{waitUntil:"networkidle2",timeout:60000});
await new Promise(r=>setTimeout(r,4500));

// 先滚到某个停靠点附近并静止
await pg.evaluate(()=>scrollTo({top:6300,behavior:"instant"}));
await new Promise(r=>setTimeout(r,1800));
const rest = await pg.evaluate(()=>Math.round(scrollY));

// 小幅滚动（约 90px，相当于一两下滚轮）后静止，看是否被吸回
await pg.mouse.move(700,450);
await pg.mouse.wheel({deltaY:90});
await new Promise(r=>setTimeout(r,2200));
const afterSmall = await pg.evaluate(()=>Math.round(scrollY));

// 大幅滚动（约 900px）后静止，应正常推进
await pg.mouse.wheel({deltaY:900});
await new Promise(r=>setTimeout(r,2400));
const afterBig = await pg.evaluate(()=>Math.round(scrollY));

console.log(`静止位置        : ${rest}`);
console.log(`小幅滚动(+90) 后 : ${afterSmall}  位移 ${afterSmall-rest}  ${Math.abs(afterSmall-rest)<60?"✓ 被吸附收拢":"未吸附"}`);
console.log(`大幅滚动(+900)后 : ${afterBig}  位移 ${afterBig-afterSmall}  ${afterBig-afterSmall>300?"✓ 正常推进":"被过度吸附"}`);
await b.close();
