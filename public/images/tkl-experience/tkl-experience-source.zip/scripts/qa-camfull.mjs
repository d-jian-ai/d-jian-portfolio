import puppeteer from "puppeteer-core";
const browser = await puppeteer.launch({
  executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
  headless: "new",
  args: ["--window-size=1440,900"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1440, height: 900 });
await page.goto("http://localhost:5173", { waitUntil: "networkidle2", timeout: 60000 });
await new Promise((r) => setTimeout(r, 4000));
await page.evaluate(()=>{window.__TKL_NOSNAP__=true;});

// 每个章节的滚动区间边界（用于标注采样点落在哪一章）
const info = await page.evaluate(() => {
  const secs = [...document.querySelectorAll(".chapter")].map((s) => {
    const r = s.getBoundingClientRect();
    return { id: s.id, top: Math.round(r.top + scrollY), h: Math.round(r.height) };
  });
  return { secs, max: document.documentElement.scrollHeight - innerHeight };
});

const N = 90;
let prev = null, prevStep = null;
const rows = [];
for (let i = 0; i <= N; i++) {
  const y = Math.round((info.max * i) / N);
  await page.evaluate((y) => scrollTo({ top: y, behavior: "instant" }), y);
  await new Promise((r) => setTimeout(r, 130));
  const d = await page.evaluate(() => window.__TKL_DEBUG__());
  const pos = d.desired;
  const tgt = d.desiredTarget;
  const dist = Math.hypot(pos[0] - tgt[0], pos[1] - tgt[1], pos[2] - tgt[2]);
  let step = null, accel = null, seen = null;
  if (prev) {
    step = Math.hypot(pos[0] - prev[0], pos[1] - prev[1], pos[2] - prev[2]);
    // 观感速度：同样的位移，离主体越近画面动得越快，所以除以机位到目标的距离
    seen = (step / Math.max(1, dist)) * 100;
    if (prevStep !== null && prevStep > 0.05) accel = step / prevStep;
  }
  // 找出所在章节
  let sec = "";
  for (const s of info.secs) if (y >= s.top - 450) sec = s.id;
  rows.push({ y, sec, step, accel, seen });
  prev = pos; prevStep = step;
}
await browser.close();

/* 用加速度（相邻步长的绝对差）判断断层：速度平滑经过零点时比值会爆炸，
   但那是平滑的；真正的断层表现为单个采样内步长的大幅突变。 */
console.log("== 运镜断层检查（相邻采样步长绝对差 > 2.5 视为断层）==");
let bad = 0;
let prevS = null;
for (const r of rows) {
  if (r.step !== null && prevS !== null) {
    const jerk = Math.abs(r.step - prevS);
    if (jerk > 2.5) {
      console.log(`  ${r.sec}  y=${r.y}  步长 ${prevS.toFixed(2)} → ${r.step.toFixed(2)}  跳变 ${jerk.toFixed(2)}`);
      bad++;
    }
  }
  if (r.step !== null) prevS = r.step;
}
console.log(bad === 0 ? "  无突变" : `  共 ${bad} 处`);

const pxPer = info.max / N;
console.log(`== 各章节镜头速度（单位位移 / 1000px 滚动）==`);
const bySec = {};
for (const r of rows) if (r.step !== null) (bySec[r.sec] ??= []).push(r);
for (const [k, v] of Object.entries(bySec)) {
  const s = v.map(r=>r.step), q = v.map(r=>r.seen);
  const avg = s.reduce((a,b)=>a+b,0)/s.length, savg = q.reduce((a,b)=>a+b,0)/q.length;
  console.log(`  ${k.padEnd(12)} 世界位移 ${avg.toFixed(2)}  峰值 ${Math.max(...s).toFixed(2)}   观感 ${savg.toFixed(2)}`);
}
