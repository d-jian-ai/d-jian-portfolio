/**
 * 轨道审计：把开场之后几段镜头换算成「方位角 / 水平半径 / 高度」，
 * 检查每一章是否都只朝一个方向转、半径不回弹。
 *
 * 判定按章节分组，且方位角先解绕——atan2 在 ±180° 处会跳变，
 * 不解绕会把正常的绕行误报成反向转动。
 */
import puppeteer from "puppeteer-core";

const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const CHAPTERS = [
  ["ch-concept", "概念"],
  ["ch-opening", "开屏"],
  ["ch-far", "远景"],
  ["ch-dive", "近景"],
];
/** 开屏是设计成等距兜圈的，半径本就该保持不变，不参与「不许拉远」的检查 */
const CONSTANT_RADIUS = new Set(["开屏"]);

const browser = await puppeteer.launch({
  executablePath: EXE,
  headless: "new",
  args: ["--no-sandbox", "--enable-webgl", "--use-gl=angle"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1440, height: 900 });
await page.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await page.evaluate(() => { window.__TKL_NOSNAP__ = true; });
await new Promise((r) => setTimeout(r, 3000));

const rows = [];
for (const [id, name] of CHAPTERS) {
  for (const f of [0, 0.25, 0.5, 0.75, 1]) {
    const cam = await page.evaluate(
      (id, f) => {
        const el = document.getElementById(id);
        window.scrollTo(0, Math.round(el.offsetTop + el.offsetHeight * f - innerHeight * 0.5));
        // 相机是指数平滑跟随的，要等它收敛，否则读到的是上一处的残影
        return new Promise((res) => setTimeout(() => res(window.__TKL_DEBUG__().cam), 1800));
      },
      id, f
    );
    const [x, y, z] = cam;
    rows.push({
      章节: name,
      位置: `${f * 100}%`,
      方位角: +((Math.atan2(z, x) * 180) / Math.PI).toFixed(1),
      水平半径: +Math.hypot(x, z).toFixed(1),
      高度: +y.toFixed(1),
    });
  }
}
console.table(rows);

const groups = {};
for (const r of rows) (groups[r.章节] ??= []).push(r);

let ok = true;
for (const [name, rs] of Object.entries(groups)) {
  // 解绕：让相邻采样的角度差落在 ±180° 内，连续累加
  const az = [];
  let prev = null;
  for (const r of rs) {
    let v = r.方位角;
    if (prev !== null) {
      while (v - prev < -180) v += 360;
      while (v - prev > 180) v -= 360;
    }
    az.push(v);
    prev = v;
  }
  const back = az.filter((v, i) => i && v < az[i - 1] - 0.4)
                 .map((v, i) => `${az[i].toFixed(1)}→${v.toFixed(1)}`);
  const rr = rs.map((r) => r.水平半径);
  const out = CONSTANT_RADIUS.has(name)
    ? []
    : rr.filter((v, i) => i && v > rr[i - 1] + 0.6).map((v) => `半径回弹到 ${v}`);

  const sweep = (az[az.length - 1] - az[0]).toFixed(0);
  const radText = CONSTANT_RADIUS.has(name)
    ? `半径 ${Math.min(...rr)}~${Math.max(...rr)}（等距兜圈）`
    : `半径 ${rr[0]} → ${rr[rr.length - 1]}`;

  const bad = back.length + out.length > 0;
  if (bad) ok = false;
  console.log(`  ${name}  转过 ${sweep}°  ${radText}  ${bad ? "✗ " + [...back, ...out].join("  ") : "✓"}`);
}
console.log(ok ? "✓ 各章方位角单调推进、半径不回弹" : "✗ 存在反向转动或拉远段");

await browser.close();
