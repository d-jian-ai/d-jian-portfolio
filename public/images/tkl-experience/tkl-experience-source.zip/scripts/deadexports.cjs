/**
 * 死导出扫描：列出 src 里 export 了、但没有任何其它文件引用的符号。
 * tsc 的 noUnusedLocals 查不到这一类——它只管文件内部。
 */
const fs = require("fs");
const path = require("path");

const files = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (e.name.endsWith(".ts")) files.push(p);
  }
})("src");

const src = Object.fromEntries(files.map((f) => [f, fs.readFileSync(f, "utf8")]));
const dead = [];

for (const [f, code] of Object.entries(src)) {
  for (const m of code.matchAll(/^export (?:const|function|class|interface|type|enum) (\w+)/gm)) {
    const name = m[1];
    const used = Object.entries(src).some(
      ([g, other]) => g !== f && new RegExp("\\b" + name + "\\b").test(other)
    );
    if (!used) dead.push(`${f.split(path.sep).join("/")}  →  ${name}`);
  }
}

console.log(`src 共 ${files.length} 个文件`);
for (const f of files) {
  console.log(`  ${String(src[f].split("\n").length).padStart(5)} 行  ${f.split(path.sep).join("/")}`);
}
console.log(`\n导出但无其它文件引用：${dead.length ? "" : "（无）"}`);
dead.forEach((d) => console.log("  " + d));
