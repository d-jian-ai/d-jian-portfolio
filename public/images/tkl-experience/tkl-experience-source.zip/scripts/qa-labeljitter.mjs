import puppeteer from "puppeteer-core";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox","--enable-webgl","--use-gl=angle"] });
const p = await b.newPage();
await p.setViewport({ width: 1440, height: 900 });
await p.goto("http://localhost:5173/", { waitUntil: "networkidle2" });
await new Promise(r => setTimeout(r, 3200));
await p.evaluate(() => { const e = document.getElementById("ch-far"); scrollTo(0, e.offsetTop + e.offsetHeight * 0.35); });
await new Promise(r => setTimeout(r, 2000));
// 边滚边逐帧采样标签屏幕坐标
const res = await p.evaluate(async () => {
  const els = [...document.querySelectorAll(".icon-label")];
  const read = () => els.map(e => { const r = e.getBoundingClientRect(); return [r.left, r.top]; });
  const frames = [];
  let n = 0;
  return await new Promise(done => {
    const step = () => {
      window.scrollBy(0, 9);            // 匀速滚动
      frames.push(read());
      if (++n < 80) requestAnimationFrame(step); else done(frames);
    };
    requestAnimationFrame(step);
  });
});
// 抖动 = 每帧位移的二阶差分（匀速滚动下理想值应接近 0）
let jerk = 0, samples = 0, maxJ = 0;
for (let i = 2; i < res.length; i++)
  for (let k = 0; k < res[i].length; k++) {
    const a = res[i-2][k], b2 = res[i-1][k], c = res[i][k];
    if (!a || !b2 || !c) continue;
    const j = Math.hypot((c[0]-b2[0])-(b2[0]-a[0]), (c[1]-b2[1])-(b2[1]-a[1]));
    if (j > 40) continue;              // 忽略进出画面的跳变
    jerk += j; samples++; if (j > maxJ) maxJ = j;
  }
console.log(`匀速滚动 80 帧，${res[0].length} 个标签`);
console.log(`  平均抖动 ${(jerk/samples).toFixed(3)} px/帧²   最大 ${maxJ.toFixed(2)} px/帧²`);
console.log(jerk/samples < 0.5 ? "✓ 抖动已在亚像素级" : "✗ 仍有可见抖动");
await b.close();
