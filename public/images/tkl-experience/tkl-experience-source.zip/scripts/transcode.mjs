import puppeteer from "puppeteer-core";
import fs from "node:fs";
import path from "node:path";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const OUT = process.argv[2] || "build-lite/media";
fs.mkdirSync(OUT, { recursive: true });

const browser = await puppeteer.launch({
  executablePath: EXE, headless: "new",
  args: ["--no-sandbox", "--autoplay-policy=no-user-gesture-required", "--enable-usermedia-screen-capturing"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1200, height: 1800 });
await page.goto("about:blank");

/** GIF → WebM：把 GIF 画到 canvas，用 MediaRecorder 录一整个循环 */
async function gif2webm(file, { seconds, w, h, scale = 1, fps = 25, kbps = 1600 }) {
  const b64 = fs.readFileSync(file).toString("base64");
  const tw = Math.round(w * scale) & ~1, th = Math.round(h * scale) & ~1;
  const out = await page.evaluate(async (b64, tw, th, seconds, fps, kbps) => {
    const img = new Image();
    img.src = "data:image/gif;base64," + b64;
    await img.decode();
    const cv = document.createElement("canvas");
    cv.width = tw; cv.height = th;
    const cx = cv.getContext("2d");
    cx.imageSmoothingQuality = "high";
    const stream = cv.captureStream(fps);
    const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm;codecs=vp8";
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: kbps * 1000 });
    const chunks = [];
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    // 先把 GIF 挂进文档让它开始播放，再从头录一个循环
    img.style.cssText = "position:fixed;left:-9999px;top:0";
    document.body.appendChild(img);
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    rec.start();
    const t0 = performance.now();
    await new Promise((done) => {
      const draw = () => {
        cx.drawImage(img, 0, 0, tw, th);
        if (performance.now() - t0 < seconds * 1000) requestAnimationFrame(draw);
        else done();
      };
      draw();
    });
    await new Promise((r) => { rec.onstop = r; rec.stop(); });
    img.remove();
    const blob = new Blob(chunks, { type: "video/webm" });
    const buf = await blob.arrayBuffer();
    let s = ""; const u8 = new Uint8Array(buf);
    for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode(...u8.subarray(i, i + 8192));
    return { b64: btoa(s), mime };
  }, b64, tw, th, seconds, fps, kbps);
  const dest = path.join(OUT, path.basename(file).replace(/\.gif$/, ".webm"));
  fs.writeFileSync(dest, Buffer.from(out.b64, "base64"));
  const before = fs.statSync(file).size, after = fs.statSync(dest).size;
  console.log(`  ${path.basename(file).padEnd(18)} ${tw}×${th}  ${(before/1048576).toFixed(1)}MB → ${(after/1048576).toFixed(2)}MB  (${(before/after).toFixed(0)}× 小)`);
  return after;
}

const { default: gifinfoMod } = await import("node:module");
const require = gifinfoMod.createRequire(import.meta.url);
const gifInfoFn = require("./gifinfo.cjs");

const targets = JSON.parse(process.env.TARGETS || "[]");
let total = 0;
for (const t of targets) total += await gif2webm(t.file, t);
console.log(`WebM 合计 ${(total/1048576).toFixed(2)} MB`);
await browser.close();
