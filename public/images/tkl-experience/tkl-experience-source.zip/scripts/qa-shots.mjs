import puppeteer from "puppeteer-core";
import { mkdirSync } from "fs";

const OUT = process.argv[2] ?? "./qa-shots";
const W = Number(process.argv[3] ?? 1440);
const H = Number(process.argv[4] ?? 900);
mkdirSync(OUT, { recursive: true });

const browser = await puppeteer.launch({
  executablePath: "C:/Program Files/Google/Chrome/Application/chrome.exe",
  headless: "new",
  args: [`--window-size=${W},${H}`, "--use-angle=default"],
});
const page = await browser.newPage();
await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message.split("\n")[0]));
await page.goto("http://localhost:5173", { waitUntil: "networkidle2", timeout: 60000 });
await new Promise((r) => setTimeout(r, 4000));

const stops = [
  ["01-hero", "#ch-hero", 0],
  ["02-context", "#ch-context", 0.5],
  ["03-concept-mid", "#ch-concept", 0.4],
  ["04-opening", "#ch-opening", 0.5],
  ["05-far", "#ch-far", 0.65],
  ["06-dive", "#ch-dive", 0.8],
  ["07-gallery", "#ch-gallery", 0.4],
  ["08-skins-a", "#ch-skins", 0.35],
  ["08-skins-b", "#ch-skins", 0.75],
  ["09-ar", "#ch-ar", 0.55],
  ["10-end", "#ch-end", 1],
];

for (const [name, sel, f] of stops) {
  const y = await page.evaluate(
    ({ sel, f }) => {
      const el = document.querySelector(sel);
      const rect = el.getBoundingClientRect();
      const top = rect.top + window.scrollY;
      const span = rect.height + innerHeight;
      return Math.max(0, Math.round(top - innerHeight + span * f));
    },
    { sel, f }
  );
  await page.evaluate((y) => window.scrollTo({ top: y, behavior: "instant" }), y);
  await new Promise((r) => setTimeout(r, 2600));
  await page.screenshot({ path: `${OUT}/${name}.jpg`, type: "jpeg", quality: 70 });
  console.log("shot", name, "y=", y);
}
await browser.close();
