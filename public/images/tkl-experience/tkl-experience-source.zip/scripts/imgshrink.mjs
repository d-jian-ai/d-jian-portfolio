import puppeteer from "puppeteer-core";
import fs from "node:fs";
import path from "node:path";
const EXE = process.env.CHROME || "C:/Program Files/Google/Chrome/Application/chrome.exe";
const OUT = process.argv[2];
fs.mkdirSync(OUT, { recursive: true });
const b = await puppeteer.launch({ executablePath: EXE, headless: "new", args: ["--no-sandbox"] });
const p = await b.newPage();
await p.goto("about:blank");
const jobs = JSON.parse(process.env.JOBS);
let before = 0, after = 0;
for (const j of jobs) {
  const src = fs.readFileSync(j.file);
  const mime = j.file.endsWith(".jpg") ? "image/jpeg" : "image/png";
  const out = await p.evaluate(async (b64, mime, maxW, q) => {
    const img = new Image();
    img.src = `data:${mime};base64,` + b64;
    await img.decode();
    const s = Math.min(1, maxW / img.naturalWidth);
    const cv = document.createElement("canvas");
    cv.width = Math.round(img.naturalWidth * s);
    cv.height = Math.round(img.naturalHeight * s);
    const cx = cv.getContext("2d");
    cx.imageSmoothingQuality = "high";
    cx.drawImage(img, 0, 0, cv.width, cv.height);
    return { url: cv.toDataURL("image/webp", q), w: cv.width, h: cv.height };
  }, src.toString("base64"), mime, j.maxW, j.q);
  const buf = Buffer.from(out.url.split(",")[1], "base64");
  const dest = path.join(OUT, path.basename(j.file).replace(/\.(png|jpg)$/, ".webp"));
  fs.writeFileSync(dest, buf);
  before += src.length; after += buf.length;
  console.log(`  ${path.basename(j.file).padEnd(24)} ${out.w}×${out.h}  ${(src.length/1024).toFixed(0)}KB → ${(buf.length/1024).toFixed(0)}KB`);
}
console.log(`图片合计 ${(before/1048576).toFixed(1)}MB → ${(after/1048576).toFixed(2)}MB  (${(before/after).toFixed(0)}× 小)`);
await b.close();
