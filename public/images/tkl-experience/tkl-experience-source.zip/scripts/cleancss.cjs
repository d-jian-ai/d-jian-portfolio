/**
 * 样式清理：
 *  1) 删除只作用于死类的规则（整条选择器列表都指向死类时才删）
 *  2) 去掉选择器列表里的重复项——img→video 的镜像跑过两次留下了重复
 */
const fs = require("fs");
const DEAD = ["phone--side", "phone--side-left", "photo-stack"];
const isDead = (sel) => DEAD.some((d) => new RegExp("\\." + d.replace(/-/g, "\\-") + "(?![\\w-])").test(sel));

let css = fs.readFileSync("src/styles.css", "utf8");
let removed = 0, deduped = 0;

css = css.replace(/([^{}]+)\{([^{}]*)\}/g, (whole, selRaw, body) => {
  const sel = selRaw.trim();
  if (!sel || sel.startsWith("@")) return whole;
  const lead = selRaw.match(/^\s*/)[0];
  let parts = sel.split(",").map((s) => s.trim()).filter(Boolean);

  const before = parts.length;
  parts = [...new Set(parts)];
  if (parts.length !== before) deduped += before - parts.length;

  const kept = parts.filter((s) => !isDead(s));
  if (kept.length === 0) { removed++; return lead.replace(/\n\s*$/, ""); }
  return lead + kept.join(",\n") + " {" + body + "}";
});

// 清掉删空后可能留下的连续空行
css = css.replace(/\n{3,}/g, "\n\n");
fs.writeFileSync("src/styles.css", css);
console.log(`删除死规则 ${removed} 条，去重选择器 ${deduped} 个`);
