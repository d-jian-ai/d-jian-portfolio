import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";
import Lenis from "lenis";
import { Experience, CameraState, K } from "../experience/Experience";
import { SKIN_SEQUENCE } from "../experience/palettes";

gsap.registerPlugin(ScrollTrigger, SplitText);

/**
 * 滚动编排
 *
 * - 章节 section 只是滚动空间；文字在 #overlays 固定浮层里，
 *   随章节进度淡入淡出——滚动过程中纹丝不动（解决跟滚晃动）。
 * - 相机：scrub 进度 → exp.desired → Experience 内部指数平滑。
 * - 全部动画建在 gsap.context() 内，destroy() 一次卸载（嵌入 Next.js 用）。
 */

interface Segment {
  el: string;
  from: CameraState;
  to: CameraState;
  mid?: { x: number; y: number; z: number };
  ease?: string;
  /** 段内进度重映射：让镜头提前到位、末尾留白（如结尾自转屏） */
  pMap?: (p: number) => number;
  onProgress?: (p: number) => void;
  onToggle?: (active: boolean) => void;
}

const lerpState = (seg: Segment, t: number, out: CameraState) => {
  const { from: a, to: b } = seg;
  if (seg.mid) {
    const u = 1 - t;
    const m = seg.mid;
    out.pos.set(
      u * u * a.pos.x + 2 * u * t * m.x + t * t * b.pos.x,
      u * u * a.pos.y + 2 * u * t * m.y + t * t * b.pos.y,
      u * u * a.pos.z + 2 * u * t * m.z + t * t * b.pos.z
    );
  } else {
    out.pos.lerpVectors(a.pos, b.pos, t);
  }
  out.target.lerpVectors(a.target, b.target, t);
};

/**
 * 构造段内进度映射：让镜头在段首缓入、段尾缓出。
 * 速度曲线是梯形（头 inF 比例从 0 线性升到 1，尾 outF 比例从 1 降到 0），
 * 位移取其归一化积分——因此速度连续，且端点速度恰为 0，
 * 用在"休止章节"（画廊 / 演进）两侧就不会出现速度断层。
 */
const ramp = (inF: number, outF: number) => {
  const total = 1 - inF / 2 - outF / 2;
  return (t: number) => {
    if (t <= 0) return 0;
    if (t >= 1) return 1;
    let area: number;
    if (t < inF) area = (t * t) / (2 * inF);
    else if (t < 1 - outF) area = inF / 2 + (t - inF);
    else {
      const u = t - (1 - outF);
      area = inF / 2 + (1 - inF - outF) + u - (u * u) / (2 * outF);
    }
    return area / total;
  };
};

const smoothstep = (x: number, min: number, max: number) => {
  const t = Math.min(1, Math.max(0, (x - min) / (max - min)));
  return t * t * (3 - 2 * t);
};

export interface ScrollHandle {
  playIntro: () => void;
  destroy: () => void;
}

export function setupScroll(exp: Experience): ScrollHandle {
  ScrollTrigger.config({ ignoreMobileResize: true });

  /* ── Lenis 平滑滚动（官方 GSAP 集成写法） ── */
  /* lerp 越小阻尼越强：微小滚轮输入被吸收，不会让画面产生细碎抖动 */
  // 内层卡片有可滚内容时让它先滚，到边界后继续驱动整页。
  let wheelRemainder = 0;
  const lenis = new Lenis({
    lerp: 0.062,
    wheelMultiplier: 0.85,
    allowNestedScroll: true,
    virtualScroll(data) {
      if (data.event.type !== "wheel") return true;
      // 保留触控板的亚像素输入，但提交整数目标。否则 .5px 目标可能
      // 一直处于指数逼近状态，Lenis 不结束，后续原生滚动会被旧目标覆盖。
      if (Math.sign(data.deltaY) !== Math.sign(wheelRemainder)) wheelRemainder = 0;
      wheelRemainder += data.deltaY;
      data.deltaY = Math.trunc(wheelRemainder);
      wheelRemainder -= data.deltaY;
      return true;
    },
  });
  const onLenisScroll = () => ScrollTrigger.update();
  lenis.on("scroll", onLenisScroll);
  const rafTick = (time: number) => lenis.raf(time * 1000);
  gsap.ticker.add(rafTick);
  gsap.ticker.lagSmoothing(0);
  const onRefresh = () => lenis.resize();
  ScrollTrigger.addEventListener("refresh", onRefresh);

  const scratch: CameraState = K(0, 0, 0, 0, 0, 0);
  let introTl: gsap.core.Timeline | null = null;

  /** 回到城市上空的转场进行中，避免重复触发及自转争抢控制权 */
  let warping = false;

  const chips = Array.from(document.querySelectorAll<HTMLElement>("#skin-chips .chip"));
  const syncChips = (pos: number) => {
    const idx = Math.round(pos);
    chips.forEach((c, i) => c.classList.toggle("is-active", i === idx));
  };


  const segments: Segment[] = [
    {
      // 开场：远景全貌，镜头比上一版更近
      el: "#ch-hero",
      from: K(43, 27, 52, 0, 6, 0),
      to: K(33, 20, 43, 0, 6, 0),
      onProgress: () => exp.city.setSignsOpacity(0),
    },
    {
      // 01 起点：环绕城市；滚动同时驱动实景照片日→夜切换
      el: "#ch-context",
      from: K(33, 20, 43, 0, 6, 0),
      to: K(-44, 22, 38, 0, 6, 0),
      onProgress(p) {
        const photo = document.getElementById("context-photo");
        photo?.style.setProperty("--photoswap", String(smoothstep(p, 0.34, 0.72)));
        exp.city.setSignsOpacity(0); // 素体阶段无标牌
      },
    },
    {
      // 02 概念：绕到背面，炸开 → 重组（保持单色，上色留给开屏章节）
      el: "#ch-concept",
      from: K(-44, 22, 38, 0, 6, 0),
      to: K(-22, 34, -40, 0, 6, 0),
      /* 这一段原本是两点之间的直线，半径会从 58 一路掉到 33 再弹回 45.6——
         镜头等于横穿城市奔向一个写死的落点。改成沿城背的圆弧：
         方位角 139°→167°→188°→209°→241° 单调推进，半径 58.1→57.7→52.3→45.6
         平滑收拢，末端的方向与开屏那段的起始切线一致，交接处没有"到站"感。 */
      mid: { x: -81.3, y: 30, z: -14.6 },
      onProgress(p) {
        // 重组一直铺到本章最末才合拢：合并完成的那一刻镜头已经走到弧线尾段，
        // 而不是停在某个设定好的点位上
        const s = p < 0.42 ? p / 0.42 : Math.max(0, 1 - (p - 0.42) / 0.58);
        exp.city.setScatter(s);
        exp.city.setSignsOpacity(0); // 炸开与重组全程无标牌
      },
    },
    {
      // 03 开屏：视频从黑白像素进化到彩色——城市同步从单色染上色彩
      el: "#ch-opening",
      from: K(-22, 34, -40, 0, 6, 0),
      to: K(45.6, 34, 0, -0.5, 6, 0),
      /* 等距兜圈：起止两点到城心的距离都是 53.5，本章只绕不拉近。
         控制点取 R = r(2 - cos(θ/2))，能让二次贝塞尔贴合半径 45.6 的圆弧
         （实测全程半径 43.0~45.7），方位角 -119° → 0° 单调推进。
         收在 0°（正右侧）：把后面的弧留给远景去兜。 */
      mid: { x: 34.6, y: 38, z: -58.6 },
      onProgress(p) {
        exp.city.setMonoMix(1 - smoothstep(p, 0.15, 0.7));
        exp.city.setSignsOpacity(0); // 开屏章节全程不出现标牌
      },
    },
    {
      // 04 远景：升到高空俯瞰，立面标牌标签点亮
      el: "#ch-far",
      from: K(45.6, 34, 0, -0.5, 6, 0),
      to: K(4.7, 14, 18.4, -1.0, 4.0, 1.0),
      /* 接着开屏的旋转方向继续走，同时螺旋收拢——不再"先拉远再拉近"。
         弧长 80°，控制点落在角平分线 40°、半径 45.7（= 均值半径 / cos(θ/2)），偏向 +z（建筑正面）那侧，
         所以路径先朝正面荡出去再收回来。终点 (4.7, 18.4) 贴在会员中心（world x 4~8 / z 8~10）正前方约 8 格处，高度也压到 14。实测方位角 0°→18°→35°→53°→80° 单调增，
         半径 45.6→40.9→36.4→30.6→24.4 单调减：只朝一个方向转、一路收近。 */
      mid: { x: 32.3, y: 26, z: 25.1 },
      onToggle(a) {
        exp.setLabelsOn(a);
      },
      onProgress(p) {
        // 标牌在远景章节开头浮现（此前的章节全程无标牌）
        exp.city.setSignsOpacity(smoothstep(p, 0.06, 0.26));
      },
    },
    {
      // 05 近景：俯冲入城，落点对准中央雕塑纵列（基座→铬雕塑→飞行器）
      el: "#ch-dive",
      from: K(4.7, 14, 18.4, -1.0, 4.0, 1.0),
      to: K(-5.8, 3.4, 13.2, -1.5, 4.4, 3.5),
      /* 远景已经绕到 80°，近景只需再转 33.7°——横向变化很小，
         主要是往下沉、往里收：高度 18→3.4、半径 24.4→14.4，
         看上去就是"降下去拉近"，而不是再绕半圈。 */
      mid: { x: -1.5, y: 10, z: 17.6 },
    },
    {
      // 06 界面画廊：前景遮挡期间，机位悄悄退到中景
      el: "#ch-gallery",
      from: K(-5.8, 3.4, 13.2, -1.5, 4.4, 3.5),
      to: K(32, 19, 40, -1.5, 5, 1),
    },
    {
      // 07 延展：沿弧线拉出环绕；环绕楼群回满色，让换肤铺满全城
      el: "#ch-skins",
      from: K(32, 19, 40, -1.5, 5, 1),
      to: K(-40, 24, 44, 0, 6, 0),
      mid: { x: 4, y: 32, z: 64 },
      onProgress(p) {
        const w = smoothstep(p, 0, 0.2) * (1 - smoothstep(p, 0.85, 1));
        exp.city.setRingWash(0.12 * (1 - w));
        exp.city.setBaseReturn(0); // 本章要看到联名本身
      },
    },
    {
      // 08 演进：承接上一段的向左运动，并在本章中段（约 62%）平滑折返向右，
      // 折返点放在章节内部而不是交界处，衔接才不会"先左突然向右"。
      el: "#ch-ar",
      from: K(-40, 24, 44, 0, 6, 0),
      to: K(-46, 27, 12, 0, 6.5, 0),
      mid: { x: -56, y: 26, z: 32 },
      // 从高定金香槟平缓回到基础配色：直接混合，不经过任何中间联名
      // 回归基础配色：铺满整个演进章节，慢慢褪回来
      onProgress: (p) => exp.city.setBaseReturn(smoothstep(p, 0.08, 0.95)),
    },
    {
      // 后记：沿弧线稳稳转到正面远景。终点距离与开场相当，不再过度拉远；
      // 停稳后由 setAutoSpin 让场景缓慢自转。
      el: "#ch-end",
      from: K(-46, 27, 12, 0, 6.5, 0),
      to: K(30, 20, 38, 0, 6, 0), // 终点比开场略近
      /* 控制点大幅外扩并抬高：镜头先荡开、越过城市上空再俯身回落，
         视差和高差都足够强。x 仍单调递增（-44 → -16 → 30），
         所以不会出现"向左闪回再向右"，冲击力和连贯性两者兼顾。 */
      mid: { x: -34, y: 27, z: 36 },
      /* 全片唯一带缓动的一段：这是真正的终点，需要"停稳"。
         用 ease-out 而非 inOut——起始速度与上一段的匀速衔接，末端才减速。
         80% 时到位，最后一屏留给自转。 */
      // 段首从演进的低速缓缓提起，末端在最后一屏之前停稳（之后交给自转）
      // 唯一保留的缓动：终点到站收势（纯尾部减速，不做缓入）
      pMap: (p) => ramp(0, 0.34)(Math.min(1, p / 0.84)),
    },
  ];

  /* ═══════════ 全部动画收进 context ═══════════ */
  const ctx = gsap.context(() => {
    const mm = gsap.matchMedia();

    mm.add(
      {
        isDesktop: "(min-width: 821px)",
        isMobile: "(max-width: 820px)",
        reduceMotion: "(prefers-reduced-motion: reduce)",
      },
      (mmCtx) => {
        const { isDesktop, reduceMotion } = mmCtx.conditions as {
          isDesktop: boolean;
          isMobile: boolean;
          reduceMotion: boolean;
        };

        /* ── 相机段落 ── */
        for (const seg of segments) {
          if (reduceMotion) {
            ScrollTrigger.create({
              trigger: seg.el,
              start: "top 60%",
              end: "bottom 40%",
              onToggle(self) {
                if (self.isActive) {
                  lerpState(seg, 1, scratch);
                  exp.desired.pos.copy(scratch.pos);
                  exp.desired.target.copy(scratch.target);
                  seg.onProgress?.(1);
                }
                seg.onToggle?.(self.isActive);
              },
            });
            continue;
          }
          const easeFn = seg.ease ? gsap.parseEase(seg.ease) : null;
          ScrollTrigger.create({
            trigger: seg.el,
            /* 关键：以视口中线为界，相邻章节首尾相接、互不重叠。
               用 top bottom / bottom top 时每对相邻区间会重叠整整一屏，
               两段同时写相机、后者覆盖前者，这正是衔接不自然的根因。 */
            start: seg.el === "#ch-hero" ? "top top" : "top center",
            end: "bottom center",
            scrub: true,
            onUpdate(self) {
              const raw = seg.pMap ? seg.pMap(self.progress) : self.progress;
              const p = easeFn ? easeFn(raw) : raw;
              lerpState(seg, p, scratch);
              exp.desired.pos.copy(scratch.pos);
              exp.desired.target.copy(scratch.target);
              seg.onProgress?.(p);
            },
            onToggle(self) {
              seg.onToggle?.(self.isActive);
            },
          });
        }
        if (reduceMotion) {
          exp.city.setScatter(0);
          exp.city.setMonoMix(0);
        }

        /* ── 后记三拍：标题 → 正文 → 全景无 UI ── */
        const endOverlay = document.querySelector<HTMLElement>(".overlay--end");
        if (endOverlay) {
          const stages = Array.from(endOverlay.querySelectorAll<HTMLElement>(".end-stage"));
          const band = (p: number, a: number, b: number, c: number, d: number) =>
            smoothstep(p, a, b) * (1 - smoothstep(p, c, d));
          ScrollTrigger.create({
            trigger: "#ch-end",
            start: "top top",
            end: "bottom bottom",
            scrub: true,
            onUpdate(self) {
              const p = self.progress;
              const o = [
                band(p, 0.04, 0.16, 0.28, 0.4), // 一拍：只有标题
                band(p, 0.44, 0.56, 0.7, 0.82), // 二拍：正文与信息
                smoothstep(p, 0.86, 0.96), // 三拍：全景，只留按钮
              ];
              stages.forEach((el, i) => {
                el.style.opacity = String(o[i]);
                el.style.visibility = o[i] > 0.01 ? "visible" : "hidden";
                el.style.transform = `translateY(${(1 - o[i]) * 22}px)`;
              });
              endOverlay.classList.toggle("is-on", Math.max(...o) > 0.01);
            },
          });
        }

        /* ── 浮层：随章节进度淡入淡出，滚动中位置固定 ── */
        const overlays = gsap.utils
          .toArray<HTMLElement>("#overlays .overlay")
          .filter((el) => !el.classList.contains("overlay--end"));
        for (const overlay of overlays) {
          const forSel = `#${overlay.dataset.for}`;
          if (!document.querySelector(forSel)) continue;
          if (reduceMotion) {
            ScrollTrigger.create({
              trigger: forSel,
              start: "top 60%",
              end: "bottom 40%",
              onToggle(self) {
                overlay.classList.toggle("is-on", self.isActive);
                overlay.style.opacity = self.isActive ? "1" : "0";
              },
            });
            continue;
          }
          ScrollTrigger.create({
            trigger: forSel,
            // 与相机区间同源（略微提前进入、延后退出，形成交叉淡化）
            start: "top 78%",
            end: "bottom 22%",
            scrub: true,
            onUpdate(self) {
              const p = self.progress;
              /* 淡入起点 / 淡出终点可由 data-fade-in、data-fade-out 覆写：
                 远景提前收、近景延后开，两者之间就留出一段纯画面的间歇。 */
              const i0 = +(overlay.dataset.fadeIn ?? 0.06);
              const o1 = +(overlay.dataset.fadeOut ?? 0.94);
              const fadeIn = smoothstep(p, i0, i0 + 0.14);
              const fadeOut = 1 - smoothstep(p, o1 - 0.14, o1);
              const o = fadeIn * fadeOut;
              overlay.style.opacity = String(o);
              overlay.style.transform = `translateY(${(1 - fadeIn) * 34 - (1 - fadeOut) * 22}px)`;
              /* 不再做入场模糊：filter 会让整层浮层（含正在播放的视频）每帧重新
                 栅格化，实测在章节交界处会多出 20~30ms 的长帧。淡入 + 上移已经够了。 */
              overlay.classList.toggle("is-on", o > 0.01);
            },
          });
        }

        /* 后记不再复位色板：把 skinPos 插值回 0 必然依次经过
           星夜→波普→蒙德里安，视觉上就是"回闪其他颜色"。
           保留观众最后选定的皮肤，结尾更连贯。 */

        /* ── 换肤进度 ── */
        ScrollTrigger.create({
          trigger: "#ch-skins",
          start: "top 45%",
          end: "bottom 80%",
          scrub: reduceMotion ? false : true,
          onUpdate(self) {
            /* 不要在 progress<=0 时提前 return——那样滚回上方章节时
               skinPos 会停在最后选中的联名（例如星夜），导致后续章节
               一路残留花纹墙体。让本章完整拥有 skinPos 的全区间。 */
            const pos = self.progress * (SKIN_SEQUENCE.length - 1);
            if (self.progress > 0) exp.city.setMonoMix(0);
            exp.city.setSkinPos(pos);
            syncChips(pos);
          },
        });

        /* ── 界面画廊：横向推进 + 焦点放大（居中的样机放大，两侧收小变淡） ── */
        const track = document.getElementById("gallery-track")!;
        const pin = document.getElementById("gallery-pin")!;
        const phones = Array.from(track.querySelectorAll<HTMLElement>(".phone"));
        const updateFocus = () => {
          const mid = innerWidth / 2;
          // 原生横滚先批量测量，再更新样式，避免逐张读写触发布局。
          const focuses = phones.map((phone) => {
            const r = phone.getBoundingClientRect();
            const d = Math.abs(r.left + r.width / 2 - mid);
            return Math.max(0, 1 - d / (innerWidth * 0.3));
          });
          phones.forEach((phone, i) => phone.style.setProperty("--focus", focuses[i].toFixed(3)));
        };
        if (isDesktop && !reduceMotion) {
          /* 位移直接由滚动进度驱动：首、尾样机都能正好停在屏幕正中。
             （用 fromTo 的函数式起始值在 pin 场景下不可靠，会到不了最后一张） */
          const setTrackX = gsap.quickSetter(track, "x", "px");
          let centers: number[] = [];
          let viewportMid = innerWidth / 2;
          let sx = 0;
          let ex = 0;
          const measure = () => {
            if (!phones.length) return;
            viewportMid = innerWidth / 2;
            centers = phones.map((phone) => phone.offsetLeft + phone.offsetWidth / 2);
            sx = viewportMid - centers[0];
            ex = viewportMid - centers[centers.length - 1];
          };
          const applyGallery = (p: number) => {
            const x = sx + (ex - sx) * p;
            setTrackX(x);
            phones.forEach((phone, i) => {
              const focus = Math.max(0, 1 - Math.abs(centers[i] + x - viewportMid) / (viewportMid * 0.6));
              phone.style.setProperty("--focus", focus.toFixed(3));
            });
          };
          measure();
          ScrollTrigger.create({
            trigger: "#ch-gallery",
            start: "top top",
            end: () => `+=${Math.max(1, sx - ex)}`,
            pin,
            invalidateOnRefresh: true,
            anticipatePin: 1,
            refreshPriority: 1,
            onRefreshInit: measure,
            onRefresh(self) {
              measure();
              applyGallery(self.progress);
            },
            onUpdate(self) {
              applyGallery(self.progress);
            },
          });
        } else {
          track.classList.add("is-native-scroll");
          gsap.set(track, { clearProps: "transform" });
          phones.forEach((p) => p.style.setProperty("--focus", "1"));
          track.addEventListener("scroll", updateFocus, { passive: true });
        }

        /* ── 流内元素 reveal（hero 之外只剩画廊头与结尾） ── */
        gsap.utils
          .toArray<HTMLElement>(".gallery-head, .end-copy")
          .forEach((el) => {
            gsap.from(el, {
              opacity: 0,
              y: reduceMotion ? 0 : 36,
              duration: reduceMotion ? 0.3 : 1,
              ease: "power3.out",
              scrollTrigger: {
                trigger: el,
                start: "top 85%",
                once: true,
                fastScrollEnd: true,
              },
            });
          });

        /* ── Hero 开场：SplitText 逐字揭示 ── */
        introTl = gsap.timeline({ paused: true });
        const splits: SplitText[] = [];
        gsap.utils.toArray<HTMLElement>(".hero-title .split-target").forEach((row, i) => {
          const split = SplitText.create(row, { type: "chars", mask: "chars" });
          splits.push(split);
          introTl!.from(
            split.chars,
            {
              yPercent: reduceMotion ? 0 : 118,
              opacity: reduceMotion ? 0 : 1,
              duration: reduceMotion ? 0.3 : 1.2,
              // power2.out 比 expo.out 更沉稳：没有那种猛地窜出的感觉
              ease: "power2.out",
              stagger: reduceMotion ? 0 : 0.038,
            },
            i * 0.16
          );
        });
        introTl
          .from(".hero-inner .hero-kicker", { opacity: 0, y: 18, duration: 1.1, ease: "power2.out" }, 0)
          .from(".hero-title .ff-arrows", { opacity: 0, scale: 0.7, duration: 0.9, ease: "back.out(1.6)" }, 0.85)
          .from(".hero-sub", { opacity: 0, y: 26, duration: 1.2, ease: "power2.out" }, 0.95)
          .from(".hero-scroll-hint", { opacity: 0, duration: 0.9 }, 1.35)
          .from("#topbar", { opacity: 0, duration: 1.1 }, 0.15);

        return () => {
          splits.forEach((s) => s.revert());
          introTl?.kill();
          introTl = null;
          track.classList.remove("is-native-scroll");
          track.removeEventListener("scroll", updateFocus);
        };
      }
    );

    /* ── 开屏视频：进入章节才加载并播放 ── */
    const video = document.querySelector<HTMLVideoElement>(".video-stage video");
    if (video) {
      ScrollTrigger.create({
        trigger: "#ch-opening",
        start: "top 80%",
        end: "bottom 20%",
        onToggle(self) {
          if (self.isActive) {
            video.preload = "auto";
            video.play().catch(() => {});
          } else {
            video.pause();
          }
        },
      });
    }

    /* ── 换肤色卡：点击平滑过渡 ── */
    const skinProxy = { v: 0 };
    chips.forEach((chip, i) => {
      chip.addEventListener("click", () => {
        skinProxy.v = exp.city.getSkinPos();
        gsap.to(skinProxy, {
          v: i,
          duration: 1.1,
          ease: "power2.inOut",
          overwrite: true,
          onUpdate() {
            exp.city.setMonoMix(0);
            exp.city.setSkinPos(skinProxy.v);
          },
        });
        syncChips(i);
      });
    });

    /* ── 左侧黄线进度轨 ── */
    const fill = document.getElementById("rail-fill")!;
    const dotsWrap = document.getElementById("rail-dots")!;
    const sections = gsap.utils.toArray<HTMLElement>(".chapter");
    const dots = sections.map((sec) => {
      const li = document.createElement("li");
      li.dataset.title = sec.dataset.title ?? "";
      li.addEventListener("click", () => lenis.scrollTo(sec, { duration: 1.6 }));
      dotsWrap.appendChild(li);
      return li;
    });
    // 连续滚动由用户控制；不在停顿后把小幅输入吸回上个位置。

    ScrollTrigger.create({
      start: 0,
      end: () => ScrollTrigger.maxScroll(window),
      invalidateOnRefresh: true,
      onUpdate(self) {
        fill.style.height = `${self.progress * 100}%`;
        // 自转只在真正停在底部时开启；稍一上滚立即交还给滚动镜头
        // 转场期间必须锁死自转，否则它会和相机归位争抢控制权
        const atBottom = ScrollTrigger.maxScroll(window) - self.scroll() < 3;
        exp.setAutoSpin(!warping && atBottom ? 1 : 0);
      },
    });
    sections.forEach((sec, i) => {
      ScrollTrigger.create({
        trigger: sec,
        start: "top 50%",
        end: "bottom 50%",
        onToggle(self) {
          if (self.isActive) dots.forEach((d, j) => d.classList.toggle("is-active", j === i));
        },
      });
    });

    /* 回到街区上空：不做"倒放整篇"的反向滚动，而是复用概念章节的体素语言——
       城市散开 → 在散开的掩护下把滚动与相机瞬时归位 → 城市重新聚合成开场画面。 */
    /* 用 document 捕获阶段 + pointerdown：
       比绑在按钮上的 click 稳得多——不受浮层堆叠顺序、pointer-events 继承、
       或任何在冒泡途中吞掉 click 的逻辑影响。 */
    /* 触发器加固：
       - pointerdown 与 click 双保险（任一先到即执行，warping 保证只跑一次）
       - 捕获阶段监听 document，不受浮层堆叠 / pointer-events / 冒泡拦截影响
       - 看门狗：万一时间线异常中断，8 秒后强制解锁，不会永久卡住 */
    const backBtn = document.getElementById("back-top");
    const startWarp = (ev: Event) => {
      const t = ev.target as HTMLElement | null;
      let onBtn = !!t && !!t.closest("#back-top");
      /* 坐标兜底：即便有浮层把事件目标抢走，只要指针落在按钮矩形内就算命中。
         这让按钮的优先级高于任何堆叠顺序 / pointer-events 继承。 */
      if (!onBtn && backBtn && backBtn.offsetParent !== null) {
        const pe = ev as PointerEvent;
        const r = backBtn.getBoundingClientRect();
        if (r.width > 0 && typeof pe.clientX === "number")
          onBtn = pe.clientX >= r.left && pe.clientX <= r.right && pe.clientY >= r.top && pe.clientY <= r.bottom;
      }
      if (!onBtn) return;
      if (import.meta.env.DEV) console.log("[回到上空] 已触发", ev.type, "warping=", warping);
      if (warping) return;
      warping = true;
      window.setTimeout(() => {
        if (warping) {
          warping = false;
          lenis.start();
          document.body.classList.remove("is-warping");
        }
      }, 8000);
      /* 回到街区上空：一次"波纹式消散 → 重建"。
         方块沿离城心的距离由内向外依次升空、缩小、消融；画面归空后
         才做滚动与相机的瞬时归位，因此跳转完全不可见；随后由外向内
         逐层落回，重新聚成开场画面。炸开效果留给概念章节专用，两处不重复。 */
      const proxy = { d: 0 };
      const push = () => exp.city.setDissolve(proxy.d);
      document.body.classList.add("is-warping");
      lenis.stop();
      /* 先冻结再消散：freezeSpin 把已转过的角度并入机位，
         所以旋转是"就地停住"，而不是倒着转回自转起点。 */
      exp.freezeSpin();

      gsap.timeline({
        onComplete() {
          document.body.classList.remove("is-warping");
          lenis.start();
          warping = false;
        },
      })
        // 消散：由内向外一圈圈升空消融
        .to(proxy, { d: 1, duration: 1.9, ease: "power1.inOut", onUpdate: push })
        // 画面已空：此刻归位，跳转不可见
        .add(() => {
          lenis.scrollTo(0, { immediate: true, force: true });
          // 兜底：Lenis 若因任何状态未生效，用原生滚动强制归零再同步回去
          if (window.scrollY > 5) {
            window.scrollTo(0, 0);
            lenis.scrollTo(0, { immediate: true, force: true });
          }
          ScrollTrigger.update();
          exp.snapCamera();
          exp.city.setDissolve(1);
        })
        .to({}, { duration: 0.12 })
        // 重建：由外向内逐层落回
        .to(proxy, { d: 0, duration: 2.6, ease: "power2.out", onUpdate: push })
        // 文字与重建的尾段重叠登场，不必空等整条时间线跑完
          .add(() => {
            /* 必须先摘掉 is-warping 再播开场：该类会把 .hero-inner 透明度压到 0，
               若留到时间线结束才摘，文字的上划动画会在遮罩下白播一遍。 */
            document.body.classList.remove("is-warping");
            introTl?.play(0);
          }, "-=1.35");
    };
    document.addEventListener("pointerdown", startWarp, true);
    document.addEventListener("click", startWarp, true);
  });

  /* ── 图片 / 字体就绪后统一重算 ── */
  const refreshWhenReady = () => {
    const imgs = Array.from(document.images).filter((img) => !img.complete);
    if (!imgs.length) {
      ScrollTrigger.refresh(true);
      return;
    }
    let left = imgs.length;
    const done = () => {
      if (--left <= 0) ScrollTrigger.refresh(true);
    };
    imgs.forEach((img) => {
      img.addEventListener("load", done, { once: true });
      img.addEventListener("error", done, { once: true });
    });
  };
  document.fonts?.ready.then(() => ScrollTrigger.refresh(true));
  window.addEventListener("load", refreshWhenReady, { once: true });
  refreshWhenReady();

  // 调试探针：仅开发环境挂载，生产构建会被摇树移除
  if (import.meta.env.DEV) {
  /* 各标牌最终挂在哪一格、朝哪一面 */
  (window as any).__TKL_SIGNS__ = () =>
    ((exp.city as any).allSigns ?? []).map((h: any) => h.userData.mount).filter(Boolean);
  /* 读回实例矩阵中浮动方块的实际 Y：验证浮动确实生效，并实测幅度。
     （只看 cluster.offset 不够——矩阵有没有真的写下去是两回事。） */
  (window as any).__TKL_MATY__ = () => {
    const c = exp.city as any;
    const out: Record<string, number> = {};
    for (const b of c.buildings ?? []) {
      const i = b.cubes.findIndex((cu: any) => cu.floatCluster >= 0);
      if (i < 0) continue;
      out[b.index] = +b.mesh.instanceMatrix.array[i * 16 + 13].toFixed(3);
    }
    return out;
  };
  /* 悬浮碰撞检查：每个悬浮簇下沉时，与其正下方静止方块的最小净空。 */
  (window as any).__TKL_FLOATCHK__ = () => {
    const c = exp.city as any;
    const out: any[] = [];
    for (const b of c.buildings ?? []) {
      const per = new Map<number, { n: number; clear: number }>();
      const columns = new Map<string, number[]>();
      for (const cu of b.cubes) {
        if (cu.floatCluster >= 0) continue;
        const k = cu.x + "," + cu.z;
        const arr = columns.get(k);
        if (arr) arr.push(cu.y);
        else columns.set(k, [cu.y]);
      }
      for (const cu of b.cubes) {
        if (cu.floatCluster < 0) continue;
        const e = per.get(cu.floatCluster) ?? { n: 0, clear: Infinity };
        e.n++;
        for (const sy of columns.get(cu.x + "," + cu.z) ?? [])
          if (sy < cu.y) e.clear = Math.min(e.clear, cu.y - sy - 1);
        per.set(cu.floatCluster, e);
      }
      for (const [cid, e] of per) {
        const cl = b.clusters[cid];
        const sink = -cl.down; // 实际下沉量
        out.push({
          楼: b.index,
          簇: cid,
          方块数: e.n,
          最小净空: e.clear === Infinity ? "悬空" : +e.clear.toFixed(2),
          行程: `${cl.down.toFixed(2)} ~ ${cl.up.toFixed(2)}`,
          幅度: +(cl.up - cl.down).toFixed(2),
          判定: e.clear === Infinity || sink <= e.clear + 1e-6 ? "OK" : "穿模 " + (sink - e.clear).toFixed(2),
        });
      }
    }
    return out;
  };
  /* 消散同步探针：给定消散度，返回方块消失比例与标牌消失比例，两者应当同步。 */
  (window as any).__TKL_DISSOLVE__ = (v: number) => {
    const c = exp.city as any;
    c.setDissolve(v);
    let cubes = 0, gone = 0;
    for (const b of c.buildings ?? [])
      for (const cu of b.cubes) { cubes++; if (c.localDissolve(cu.wave) > 0.99) gone++; }
    const signs = c.allSigns ?? [];
    const signGone = signs.filter((h: any) => !h.visible).length;
    return {
      消散度: v,
      方块已消失: +(gone / Math.max(1, cubes) * 100).toFixed(1),
      标牌已消失: +(signGone / Math.max(1, signs.length) * 100).toFixed(1),
      飞行器: c.portal.group.visible, 雕塑: c.chrome.mesh.visible,
    };
  };
  (window as any).__TKL_DEBUG__ = () => {
    const c = exp.city as any;
    const cam = exp.camera.position;
    return {
      cam: [+cam.x.toFixed(2), +cam.y.toFixed(2), +cam.z.toFixed(2)],
      desired: [
        +exp.desired.pos.x.toFixed(2),
        +exp.desired.pos.y.toFixed(2),
        +exp.desired.pos.z.toFixed(2),
      ],
      desiredTarget: [
        +exp.desired.target.x.toFixed(2),
        +exp.desired.target.y.toFixed(2),
        +exp.desired.target.z.toFixed(2),
      ],
      autoSpin: (exp as any).autoSpin,
      skinPos: exp.city.getSkinPos(),
      mapMix: c.mapMix?.value,
      monoMix: c.monoMix,
      scatter: c.scatter,
      dissolve: c.dissolve,
      baseReturn: c.baseReturn,
      floatScale: c.floatScale,
      signs: c.allSigns?.length,
      signMounts: exp.city.icons.map((i: any) => i.id + (Math.abs(i.mesh.rotation.x) > 1 ? ":顶面" : ":立面")),
      labels: exp.city.icons.length,
      floatingSigns: c.floatingSigns?.map((f: any) => ({ b: f.building.index, cl: f.cluster })),
      floatByBuilding: c.buildings
        ?.filter((x: any) => x.hasFloaters)
        .map((x: any) => ({
          idx: x.index,
          clusters: x.clusters.length,
          cells: x.cubes.filter((q: any) => q.floatCluster >= 0).length,
        })),
    };
  };
  }

  return {
    playIntro: () => introTl?.play(0),
    destroy() {
      ctx.revert();
      lenis.off("scroll", onLenisScroll);
      gsap.ticker.remove(rafTick);
      ScrollTrigger.removeEventListener("refresh", onRefresh);
      lenis.destroy();
      ScrollTrigger.getAll().forEach((t) => t.kill());
    },
  };
}
