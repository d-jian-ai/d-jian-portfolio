import * as THREE from "three";

/**
 * 中央飞行器（悬浮门户）+ 铬金属雕塑
 * 1:1 移植自原模型 taikoo-li-model.tsx 的 TaikooPortal / ChromeSculpture，
 * 原场景单位 0.62，这里按 SCALE 放大到本场景的 1 单位网格。
 */

const SCALE = 1.7;
const PORTAL_RING_TILT = Math.PI / 12; // 15° 光环倾角

/** 环形字带纹理："LET'S FASHION FORWARD •" 环排 */
function circularTextTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 1024;
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, 1024, 1024);
  ctx.fillStyle = "rgba(43,160,176,0.94)";
  ctx.beginPath();
  ctx.arc(512, 512, 465, 0, Math.PI * 2);
  ctx.arc(512, 512, 338, 0, Math.PI * 2, true);
  ctx.fill();

  const text = "LET'S FASHION FORWARD  •  LET'S FASHION FORWARD  •  ";
  ctx.font = "600 45px Arial, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,0.94)";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const radius = 405;
  const step = (Math.PI * 2) / text.length;
  [...text].forEach((character, index) => {
    const angle = index * step - Math.PI / 2;
    ctx.save();
    ctx.translate(512 + Math.cos(angle) * radius, 512 + Math.sin(angle) * radius);
    ctx.rotate(angle + Math.PI / 2);
    ctx.fillText(character, 0, 0);
    ctx.restore();
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 12;
  return tex;
}

/** 金色镂空三角框（双箭头单元） */
function triangleFrame(x: number): THREE.Mesh {
  const outer = new THREE.Shape();
  outer.moveTo(-0.68, -0.6);
  outer.lineTo(0.5, 0);
  outer.lineTo(-0.68, 0.6);
  outer.closePath();
  const hole = new THREE.Path();
  hole.moveTo(-0.42, -0.34);
  hole.lineTo(0.23, 0);
  hole.lineTo(-0.42, 0.34);
  hole.closePath();
  outer.holes.push(hole);
  const mesh = new THREE.Mesh(
    new THREE.ExtrudeGeometry(outer, {
      depth: 0.08,
      bevelEnabled: true,
      bevelSize: 0.025,
      bevelThickness: 0.025,
      bevelSegments: 3,
    }),
    new THREE.MeshPhysicalMaterial({
      color: "#ffe789",
      emissive: "#9d6500",
      emissiveIntensity: 0.35,
      metalness: 0.72,
      roughness: 0.18,
    })
  );
  mesh.position.x = x;
  return mesh;
}

export class TaikooPortal {
  group = new THREE.Group();
  private portalY: number;

  constructor(anchor: THREE.Vector3, portalY = 8.2) {
    this.portalY = portalY;
    this.group.position.set(anchor.x, portalY, anchor.z);
    this.group.scale.setScalar(SCALE);

    const tilted = new THREE.Group();
    tilted.rotation.x = PORTAL_RING_TILT;
    this.group.add(tilted);

    // 深色环体（挤出圆环，带倒角）
    const annulusShape = new THREE.Shape();
    annulusShape.absarc(0, 0, 1.78, 0, Math.PI * 2, false);
    const annulusHole = new THREE.Path();
    annulusHole.absarc(0, 0, 1.18, 0, Math.PI * 2, true);
    annulusShape.holes.push(annulusHole);
    const annulus = new THREE.Mesh(
      new THREE.ExtrudeGeometry(annulusShape, {
        bevelEnabled: true,
        bevelSegments: 3,
        bevelSize: 0.025,
        bevelThickness: 0.025,
        depth: 0.16,
      }),
      new THREE.MeshPhysicalMaterial({
        color: "#26223f",
        clearcoat: 1,
        envMapIntensity: 2.2,
        metalness: 0.42,
        opacity: 0.82,
        roughness: 0.08,
        transparent: true,
      })
    );
    annulus.position.y = 0.03;
    annulus.rotation.x = Math.PI / 2;
    tilted.add(annulus);

    // 环形字带
    const band = new THREE.Mesh(
      new THREE.RingGeometry(1.18, 1.78, 128),
      new THREE.MeshPhysicalMaterial({
        color: "#ffffff",
        map: circularTextTexture(),
        opacity: 0.94,
        roughness: 0.2,
        side: THREE.DoubleSide,
        transparent: true,
      })
    );
    band.position.y = 0.08;
    band.rotation.x = -Math.PI / 2;
    tilted.add(band);

    // 冰蓝描边
    const edge = new THREE.Mesh(
      new THREE.TorusGeometry(1.78, 0.06, 16, 128),
      new THREE.MeshPhysicalMaterial({
        color: "#d7fbff",
        clearcoat: 1,
        opacity: 0.72,
        roughness: 0.12,
        transparent: true,
      })
    );
    edge.position.y = 0.08;
    edge.rotation.x = Math.PI / 2;
    tilted.add(edge);

    // 紫玻璃悬浮球
    const sphere = new THREE.Mesh(
      new THREE.SphereGeometry(1, 64, 48),
      new THREE.MeshPhysicalMaterial({
        color: "#9b7fbd",
        clearcoat: 1,
        envMapIntensity: 2.2,
        opacity: 0.5,
        roughness: 0.08,
        thickness: 0.8,
        transparent: true,
        transmission: 0.5,
      })
    );
    sphere.scale.setScalar(1.08);
    this.group.add(sphere);

    // 金色双箭头
    const arrows = new THREE.Group();
    arrows.position.set(-0.08, 0.05, 0.24);
    arrows.rotation.x = 0.02;
    arrows.scale.setScalar(0.52);
    arrows.add(triangleFrame(-0.38), triangleFrame(0.38));
    this.group.add(arrows);
  }

  update(t: number) {
    const breath = Math.sin(t * 1.12);
    this.group.position.y = this.portalY + breath * 0.14 * SCALE;
    this.group.rotation.y = Math.sin(t * 0.24) * 0.045;
    const s = SCALE * (1 + breath * 0.014);
    this.group.scale.setScalar(s);
  }
}

/** 铬金属软雕塑（广场上的银色"软冰淇淋"） */
export class ChromeSculpture {
  mesh: THREE.Mesh;
  private baseY: number;

  constructor(position: THREE.Vector3, scale: THREE.Vector3) {
    const geo = new THREE.SphereGeometry(1, 72, 52);
    const pos = geo.attributes.position;
    const point = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      point.fromBufferAttribute(pos, i);
      const theta = Math.atan2(point.z, point.x);
      const vertical = point.y;
      const lowerWeight = (1 - vertical) * 0.5;
      const fold =
        1 +
        Math.sin(vertical * 11 + theta * 1.6) * 0.1 +
        Math.sin(vertical * 19 - theta * 0.7) * 0.04;
      point.x *= fold * (0.88 + lowerWeight * 0.22);
      point.z *= fold * (0.68 + lowerWeight * 0.14);
      point.y *= 1.08;
      point.x += Math.sin((vertical + 1) * 2.4) * 0.16 + 0.08 - vertical * 0.06;
      const twist = vertical * 0.18;
      const x = point.x * Math.cos(twist) - point.z * Math.sin(twist);
      const z = point.x * Math.sin(twist) + point.z * Math.cos(twist);
      pos.setXYZ(i, x, point.y, z);
    }
    geo.computeVertexNormals();
    this.mesh = new THREE.Mesh(
      geo,
      new THREE.MeshPhysicalMaterial({
        color: "#f6f4f2",
        envMapIntensity: 2.8,
        metalness: 1,
        roughness: 0.065,
      })
    );
    this.mesh.position.copy(position);
    this.mesh.scale.copy(scale);
    this.baseY = position.y;
  }

  update(t: number, dt: number) {
    this.mesh.rotation.y += dt * 0.18;
    this.mesh.position.y = this.baseY + Math.sin(t * 1.05) * 0.045 * 1.7;
  }
}
