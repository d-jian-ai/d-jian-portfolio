import { VOXEL_BUILDINGS, voxelKey } from "./voxel-editor-data";
import layout from "./layout.json";

/**
 * 中心建筑群：用户完整复原的 12 栋体素建筑。
 * 数据源自原始编辑器导出——含镂空删除表与最终位置，网格单位 = 1，与环绕城市一致。
 */

export interface CenterVoxel {
  x: number;
  y: number;
  z: number;
  buildingIndex: number; // 1..12
  /** 逐实例明暗抖动（原模型 presentation 模式公式，0.84–1.0） */
  variation: number;
}

/** 原模型 presentation 材质的每栋表面色（清漆树脂） */
export const BUILDING_SURFACES: Record<number, string> = {
  1: "#bd1737",
  2: "#8e0928",
  3: "#760722",
  4: "#aa3151",
  5: "#8a7063",
  6: "#202d8a",
  7: "#006f80",
  8: "#293b91",
  9: "#213181",
  10: "#19236f",
  11: "#514541",
  12: "#76564f",
};

/** 原模型主题色板：中心建筑按 (index-1) % len 取色（与源实现一致） */
export const BUILDING_THEMES: Record<string, string[]> = {
  // 纯正原色 + 白与黑，占比以白为主（对照 PPT 蒙德里安效果图）
  mondrian: ["#f2f0ea", "#e02418", "#f5c400", "#0f47c4", "#1b1b18", "#f2f0ea"],
  // 镜面糖果：金、玫瑰金、洋红、青、铬白、紫、铜（对照 PPT 波普效果图）
  koons: ["#b8860b", "#a8305f", "#0f8f96", "#c9ccd2", "#5a2d82", "#a8552a", "#1f6fb2"],
  // 星夜底色由贴图承担，这里仅留中性备用
  vangogh: ["#c8d0da", "#b9c4d2", "#cdd6e0", "#c2ccd8", "#b4c0cf"],
  // 高定金香槟：暖金、古铜、香槟、深棕（对照 PPT Dior 效果图）
  dior: ["#d9a441", "#a8712c", "#f0dcb0", "#8a5520", "#c99a4e"],
};

const deleted = new Set<string>(layout.deleted);
const positions = new Map(layout.positions.map((p) => [p.id, p]));

/** 每栋建筑的布局位置（立面标牌的 localPosition 以此为基准） */
export const BUILDING_POSITIONS: Record<number, { x: number; y: number; z: number }> =
  Object.fromEntries(
    layout.positions.map((p) => [Number(p.id.replace("building-", "")), { x: p.x, y: p.y, z: p.z }])
  );

function buildCenter(): CenterVoxel[] {
  const out: CenterVoxel[] = [];
  for (const building of VOXEL_BUILDINGS) {
    const offset = positions.get(building.id) ?? { x: 0, y: 0, z: 0 };
    for (const cell of building.cells) {
      if (deleted.has(voxelKey(building.id, cell))) continue;
      out.push({
        x: cell.x + offset.x,
        y: cell.y + offset.y + 0.5,
        z: cell.z + offset.z,
        buildingIndex: building.index,
        variation:
          0.84 +
          (((cell.x * 17 + cell.y * 11 + cell.z * 7 + building.index * 5) % 9) / 8) * 0.16,
      });
    }
  }
  return out;
}

export const TAIKOO_CENTER: CenterVoxel[] = buildCenter();

/** 中心建筑群的包围盒（xz 平面），环绕楼群据此保持净空 */
export const CENTER_BOUNDS = TAIKOO_CENTER.reduce(
  (b, v) => ({
    minX: Math.min(b.minX, v.x),
    maxX: Math.max(b.maxX, v.x),
    minZ: Math.min(b.minZ, v.z),
    maxZ: Math.max(b.maxZ, v.z),
  }),
  { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity }
);
