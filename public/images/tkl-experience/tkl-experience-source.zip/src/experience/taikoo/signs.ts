/**
 * 立面标牌：位置与尺寸 1:1 移植自原模型 taikoo-li-facade-signs.tsx，
 * localPosition 相对所属建筑的组原点（含 layout.json 的最终位置偏移已由建筑组承担）。
 */

export type SignKind =
  | "profile"
  | "community"
  | "exchange"
  | "points"
  | "login"
  | "help"
  | "parking";

export interface SignPlacement {
  buildingIndex: number;
  kind: SignKind;
  localPosition: [number, number, number];
  rotation?: [number, number, number];
  scale: number;
  url: string;
}

export const SIGN_LABELS: Record<SignKind, string> = {
  help: "会员客服",
  exchange: "积分兑换",
  community: "会员社区",
  parking: "停车服务",
  points: "会员积分",
  profile: "会员中心",
  login: "会员码",
};

// 走 BASE_URL：这串是运行时拼的，Vite 的 base 重写不会碰它
const url = (kind: SignKind) =>
  `${import.meta.env.BASE_URL}images/taikoo-li/icons/${kind}.png`;

const HALF_PI = Math.PI / 2;

/** 注意：原数据 localPosition 相对 layout.json 的建筑位置；建筑组即以该位置为原点 */
export const SIGN_PLACEMENTS: SignPlacement[] = [
  { buildingIndex: 1, kind: "help", localPosition: [3.75, 7.75, 2.54], scale: 1.48, url: url("help") },
  { buildingIndex: 2, kind: "exchange", localPosition: [4.5, 8.6, 3.54], scale: 1.5, url: url("exchange") },
  { buildingIndex: 2, kind: "exchange", localPosition: [5.05, 1.75, 3.54], scale: 0.62, url: url("exchange") },
  { buildingIndex: 3, kind: "community", localPosition: [2, 8.04, 2], rotation: [-HALF_PI, 0, 0], scale: 1.72, url: url("community") },
  { buildingIndex: 4, kind: "parking", localPosition: [3.25, 3.04, 2.15], rotation: [-HALF_PI, 0, 0], scale: 1.92, url: url("parking") },
  { buildingIndex: 4, kind: "parking", localPosition: [2, 4.04, 0], rotation: [-HALF_PI, 0, 0], scale: 0.76, url: url("parking") },
  { buildingIndex: 5, kind: "points", localPosition: [0.5, 6.85, 3.54], scale: 1.34, url: url("points") },
  { buildingIndex: 5, kind: "points", localPosition: [0.5, 2.2, 3.54], scale: 0.58, url: url("points") },
  { buildingIndex: 10, kind: "profile", localPosition: [3.5, 8.04, 0], rotation: [-HALF_PI, 0, 0], scale: 1.88, url: url("profile") },
  { buildingIndex: 11, kind: "login", localPosition: [1.5, 1, 3.54], scale: 1.56, url: url("login") },
];
