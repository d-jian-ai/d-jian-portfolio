import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { VoxelCity } from "./VoxelCity";
import { translateTklCopy } from "../i18n";

export interface CameraState {
  pos: THREE.Vector3;
  target: THREE.Vector3;
}

export const K = (px: number, py: number, pz: number, tx: number, ty: number, tz: number): CameraState => ({
  pos: new THREE.Vector3(px, py, pz),
  target: new THREE.Vector3(tx, ty, tz),
});

/** 渲染器 + 场景 + 摄像机装置。滚动逻辑只需要写 desired 状态，这里负责平滑跟随。 */
export class Experience {
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  city: VoxelCity;
  ready: Promise<void>;
  private resolveReady!: () => void;

  /** 滚动侧写入的目标机位 */
  desired: CameraState = K(43, 27, 52, 0, 6, 0);

  private currentPos = new THREE.Vector3().copy(this.desired.pos);
  private currentTarget = new THREE.Vector3().copy(this.desired.target);
  private mouse = new THREE.Vector2();
  private parallax = new THREE.Vector2();
  private clock = new THREE.Clock();
  private labelEls = new Map<string, HTMLElement>();
  /** 标签的屏幕坐标（做二次平滑用）；on=false 表示上一帧不在画面内 */
  private labelPos = new Map<string, { x: number; y: number; on: boolean }>();
  private labelsOn = false;
  private v = new THREE.Vector3();

  constructor(canvas: HTMLCanvasElement) {
    const isMobile = window.matchMedia("(max-width: 820px)").matches;
    this.ready = new Promise<void>((resolve) => (this.resolveReady = resolve));

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: !isMobile,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1 : 1.5));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;

    this.scene.background = new THREE.Color("#f1f1ef");
    this.scene.fog = new THREE.Fog("#f1f1ef", 130, 250);

    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 400);

    // 环境反射：RoomEnvironment + 暖色补光板（移植自原模型的摄影棚配置）
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const studio = new RoomEnvironment();
    const panelGeometry = new THREE.PlaneGeometry(12, 12);
    const panels = [
      { color: "#fff0d5", intensity: 4.4, position: [0, 12, 4], rotation: [Math.PI / 2, 0, 0], scale: [1.8, 1, 1] },
      { color: "#ffc38f", intensity: 3.25, position: [-11, 6, -2], rotation: [0, Math.PI / 2, 0], scale: [1.2, 1, 1] },
      { color: "#d88465", intensity: 2.65, position: [11, 5, -4], rotation: [0, -Math.PI / 2, 0], scale: [1, 0.9, 1] },
      { color: "#ffe2be", intensity: 3.1, position: [0, 6, 12], rotation: [0, 0, 0], scale: [1.4, 0.8, 1] },
    ] as const;
    for (const panel of panels) {
      const mesh = new THREE.Mesh(
        panelGeometry,
        new THREE.MeshBasicMaterial({
          color: new THREE.Color(panel.color).multiplyScalar(panel.intensity),
          side: THREE.DoubleSide,
          toneMapped: false,
        })
      );
      mesh.position.set(panel.position[0], panel.position[1], panel.position[2]);
      mesh.rotation.set(panel.rotation[0], panel.rotation[1], panel.rotation[2]);
      mesh.scale.set(panel.scale[0], panel.scale[1], panel.scale[2]);
      studio.add(mesh);
    }
    this.scene.environment = pmrem.fromScene(studio, 0.055).texture;
    pmrem.dispose();

    // 灯光：暖主光 + 冷侧逆光（轮廓感），环境光稍降让明暗更立体
    const dir = new THREE.DirectionalLight("#fff2e0", 2.1);
    dir.position.set(30, 50, 20);
    this.scene.add(dir);
    const rim = new THREE.DirectionalLight("#cfe0ff", 0.7);
    rim.position.set(-24, 30, -28);
    this.scene.add(rim);
    this.scene.add(new THREE.AmbientLight("#ffffff", 0.42));

    this.city = new VoxelCity(isMobile ? 0.6 : 1, isMobile);
    this.scene.add(this.city.group);

    // 接触阴影：中心建筑群下方一片柔和的暗渍（假 AO，成本为零但落地感强）
    const shadowCanvas = document.createElement("canvas");
    shadowCanvas.width = shadowCanvas.height = 256;
    const sctx = shadowCanvas.getContext("2d")!;
    const grad = sctx.createRadialGradient(128, 128, 20, 128, 128, 128);
    grad.addColorStop(0, "rgba(20,18,26,0.34)");
    grad.addColorStop(0.55, "rgba(20,18,26,0.16)");
    grad.addColorStop(1, "rgba(20,18,26,0)");
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 256, 256);
    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    const contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(72, 66),
      new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.set(0, 0.015, 0);
    this.scene.add(contactShadow);

    // 背景与地面始终保持浅灰摄影棚（换肤只改建筑本身，不改环境）

    this.buildIconLabels();
    /* 贴图与着色器预热：标牌贴图是异步加载的，必须等它们全部到齐再做，
       否则 compile 时纹理还是空的，开销照样留在远景章节那一帧。 */
    this.city.onSignTexReady = () => {
      this.city.warmUpSigns(this.renderer, this.scene, this.camera);
      this.renderer.render(this.scene, this.camera);
      this.resolveReady();
    };

    window.addEventListener("resize", this.onResize);
    window.addEventListener("pointermove", this.onPointerMove);
    document.addEventListener("visibilitychange", this.onVisibilityChange);
    this.resize();

    this.renderer.setAnimationLoop(() => this.tick());
  }

  /** 结尾自转：仅在滚到底部时开启；一旦滚动，镜头控制权立即交还给滚动动画 */
  private autoSpin = 0; // 目标值 0/1
  private spinBlend = 0; // 平滑后的实际混合度
  private spinAngle = 0;
  setAutoSpin(v: number) {
    this.autoSpin = THREE.MathUtils.clamp(v, 0, 1);
  }

  /** 立即冻结自转：把已累积的角度并入当前机位与目标机位后清零。
      画面既不跳变、也不会像 blend 自然衰减那样倒着转回自转起点——
      「点击后直接停止旋转」靠的就是这一步。 */
  freezeSpin() {
    const ang = this.spinAngle * this.spinBlend;
    this.autoSpin = 0;
    this.spinAngle = 0;
    this.spinBlend = 0;
    if (Math.abs(ang) < 1e-4) return;
    const cos = Math.cos(ang), sin = Math.sin(ang);
    const rot = (v: THREE.Vector3) => {
      const ox = v.x - this.currentTarget.x;
      const oz = v.z - this.currentTarget.z;
      v.x = this.currentTarget.x + ox * cos - oz * sin;
      v.z = this.currentTarget.z + ox * sin + oz * cos;
    };
    rot(this.currentPos);
    rot(this.desired.pos); // 目标位同步，否则相机会缓缓漂回未自转的位置
  }

  /** 相机瞬时归位到 desired（转场遮罩期间使用，避免归位过程被看到） */
  snapCamera() {
    this.currentPos.copy(this.desired.pos);
    this.currentTarget.copy(this.desired.target);
    this.spinAngle = 0;
    this.spinBlend = 0;
  }

  private onResize = () => this.resize();
  private onVisibilityChange = () => {
    this.renderer.setAnimationLoop(document.hidden ? null : () => this.tick());
  };
  private onPointerMove = (e: PointerEvent) => {
    this.mouse.set((e.clientX / innerWidth) * 2 - 1, (e.clientY / innerHeight) * 2 - 1);
  };

  /** 完整卸载：停循环、摘监听、释放 GPU 资源（嵌入 SPA 时必须调用） */
  destroy() {
    this.renderer.setAnimationLoop(null);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("pointermove", this.onPointerMove);
    document.removeEventListener("visibilitychange", this.onVisibilityChange);
    this.labelEls.forEach((el) => el.remove());
    this.labelEls.clear();
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (!mat) return;
      const list = Array.isArray(mat) ? mat : [mat];
      for (const m of list) {
        for (const value of Object.values(m)) {
          if (value && (value as THREE.Texture).isTexture) (value as THREE.Texture).dispose();
        }
        m.dispose();
      }
    });
    this.scene.environment?.dispose();
    this.renderer.dispose();
  }

  private buildIconLabels() {
    const wrap = document.getElementById("icon-labels")!;
    for (const icon of this.city.icons) {
      const el = document.createElement("div");
      el.className = "icon-label";
      el.textContent = translateTklCopy(icon.label);
      wrap.appendChild(el);
      this.labelEls.set(icon.id, el);
      this.labelPos.set(icon.id, { x: 0, y: 0, on: false });
    }
  }

  /** ch4 远景章节开关标签 */
  setLabelsOn(on: boolean) {
    if (on === this.labelsOn) return;
    this.labelsOn = on;
    if (!on) {
      this.labelEls.forEach((el) => el.classList.remove("is-on"));
      // 重新入画时要直接就位，否则会从上次的旧坐标滑进来
      this.labelPos.forEach((s) => (s.on = false));
    }
  }

  private resize() {
    const w = innerWidth, h = innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  private tick() {
    // 必须先取 delta 再读 elapsedTime：getElapsedTime() 内部会消费掉 delta，
    // 反序会让 dt 恒接近 0，相机平滑系数随之失真。
    const dt = Math.min(this.clock.getDelta(), 0.05) || 0.016;
    const t = this.clock.elapsedTime;

    // 平滑跟随目标机位（丝滑的关键：帧率无关的指数平滑）
    // 跟随时间常数放缓：镜头更有惯性，微小滚动不会立刻反映为画面抖动
    const k = 1 - Math.exp(-dt * 3.4);
    this.parallax.lerp(this.mouse, 1 - Math.exp(-dt * 2.5));
    this.currentPos.lerp(this.desired.pos, k);
    this.currentTarget.lerp(this.desired.target, k);

    // 鼠标视差：在机位垂直平面上偏移
    const dist = this.currentPos.distanceTo(this.currentTarget);
    const px = this.parallax.x * Math.min(2.4, dist * 0.04);
    const py = -this.parallax.y * Math.min(1.4, dist * 0.025);
    this.camera.position.copy(this.currentPos);

    /* 结尾自转：只在停在底部时累积角度；离开底部后 blend 平滑归零，
       相机自然回到滚动动画给定的位置，两者不会同时争夺控制权。 */
    this.spinBlend += (this.autoSpin - this.spinBlend) * (1 - Math.exp(-dt * 1.8));
    if (this.autoSpin > 0.5) this.spinAngle += dt * 0.05;
    else if (this.spinBlend < 0.002) this.spinAngle = 0;
    const spinAng = this.spinAngle * this.spinBlend;
    if (Math.abs(spinAng) > 1e-4) {
      const ox = this.camera.position.x - this.currentTarget.x;
      const oz = this.camera.position.z - this.currentTarget.z;
      const cos = Math.cos(spinAng);
      const sin = Math.sin(spinAng);
      this.camera.position.x = this.currentTarget.x + ox * cos - oz * sin;
      this.camera.position.z = this.currentTarget.z + ox * sin + oz * cos;
    }

    this.camera.position.x += px;
    this.camera.position.y += py;
    this.camera.lookAt(this.currentTarget);

    this.city.update(t);
    this.city.updateOcclusion(this.camera.position, this.currentTarget);

    // 图标标签投影
    if (this.labelsOn) {
      // 屏幕空间再做一层平滑：相机已经是平滑的，但投影对机位极敏感，
      // 近处标签仍会随滚动高频抖动。约 90ms 的时间常数够压住抖，又不会明显拖尾。
      const la = 1 - Math.exp(-dt * 11);
      for (const icon of this.city.icons) {
        const el = this.labelEls.get(icon.id)!;
        const s = this.labelPos.get(icon.id)!;
        // 用挂载基准点而非实时世界坐标：牌子随建筑浮动，但文字标签保持稳定
        this.v.copy(icon.worldPos);
        this.v.y += 1.4;
        this.v.project(this.camera);
        const behind = this.v.z > 1;
        if (behind || Math.abs(this.v.x) > 1.05 || Math.abs(this.v.y) > 1.05) {
          el.classList.remove("is-on");
          s.on = false;
          continue;
        }
        const tx = (this.v.x * 0.5 + 0.5) * innerWidth;
        const ty = (-this.v.y * 0.5 + 0.5) * innerHeight;
        if (s.on) {
          s.x += (tx - s.x) * la;
          s.y += (ty - s.y) * la;
        } else {
          s.x = tx;
          s.y = ty;
          s.on = true;
        }
        el.classList.add("is-on");
        el.style.transform = `translate3d(${s.x.toFixed(2)}px, ${s.y.toFixed(2)}px, 0) translate(-50%, -130%)`;
      }
    }

    this.renderer.render(this.scene, this.camera);
  }
}
