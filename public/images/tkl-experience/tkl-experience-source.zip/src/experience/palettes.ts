import * as THREE from "three";

/** 色彩家族：每个方向的楼群从对应家族中取色（呼应样机：西红东蓝北青南暖） */
export interface Palette {
  name: string;
  west: string[]; // -x 方向
  east: string[]; // +x 方向
  north: string[]; // -z 方向
  south: string[]; // +z 方向
  ground: string;
}

export const PALETTES: Record<string, Palette> = {
  /** 单色（Hero/背景章节的“未上色”状态，呼应 PPT 灰白线框） */
  mono: {
    name: "mono",
    west: ["#ffffff", "#ececec", "#dcdcdc"],
    east: ["#f8f8f8", "#e4e4e4", "#d2d2d4"],
    north: ["#ffffff", "#e8e8ea", "#d8d8da"],
    south: ["#f4f4f2", "#e2e2e0", "#d6d6d2"],
    ground: "#ececea",
  },
  /** 默认玻璃宝石色（Let's Fashion Forward 首页配色） */
  glass: {
    name: "glass",
    west: ["#d40f2c", "#ff5a3c", "#8c1020", "#e8742c"],
    east: ["#2434c8", "#3c50e0", "#141c78", "#5064e8"],
    north: ["#14b4c8", "#1890b4", "#0c6880"],
    south: ["#c88a3c", "#b0b0b8", "#d8d8e0"],
    ground: "#ececea",
  },
  /** Mondrian 几何抽象 */
  mondrian: {
    name: "mondrian",
    west: ["#e02020", "#f4f4f4", "#e02020"],
    east: ["#1b4bd2", "#f4f4f4", "#1b4bd2"],
    north: ["#f7d417", "#f4f4f4"],
    south: ["#f4f4f4", "#f7d417", "#17181c"],
    ground: "#f4f4f2",
  },
  /** Jeff Koons 新表现主义（气球狗金属糖果色） */
  koons: {
    name: "koons",
    west: ["#ff7ab8", "#f0439a", "#ffb0d4"],
    east: ["#c46ce0", "#9a4ad0", "#d8a0f0"],
    north: ["#7de0d8", "#4ac8c0"],
    south: ["#f0c0d8", "#e8e8f0", "#ffd88a"],
    ground: "#f6eef2",
  },
  /** van Gogh 后印象派（星夜） */
  vangogh: {
    name: "vangogh",
    west: ["#f2c744", "#e8a020", "#d88818"],
    east: ["#1e3a8a", "#3b6bd8", "#152860"],
    north: ["#2c5090", "#4878c0"],
    south: ["#3a6858", "#f2c744", "#28406e"],
    ground: "#eae6d8",
  },
  /** Dior J'adore（金香槟） */
  dior: {
    name: "dior",
    west: ["#d8b060", "#c89840", "#f0d8a0"],
    east: ["#e8b4b8", "#d89498", "#f4d8da"],
    north: ["#b89868", "#e0c890"],
    south: ["#503028", "#d8c8a8", "#f0e4c8"],
    ground: "#f2ece0",
  },
};

/** 换肤章节的滚动顺序 */
export const SKIN_SEQUENCE = ["glass", "mondrian", "koons", "vangogh", "dior"] as const;

const tmp = new THREE.Color();

/** 依据方位角与随机值从 palette 中为一个方块取色，写入 out */
export function pickColor(
  palette: Palette,
  angle: number, // atan2(z, x)
  rand: number, // 0..1 稳定随机
  out: THREE.Color
): void {
  const deg = ((angle * 180) / Math.PI + 360) % 360;
  let family: string[];
  if (deg >= 120 && deg < 240) family = palette.west;
  else if (deg < 60 || deg >= 300) family = palette.east;
  else if (deg >= 240) family = palette.north;
  else family = palette.south;
  tmp.set(family[Math.floor(rand * family.length) % family.length]);
  // 轻微明度抖动，避免大片死板
  const jitter = 0.92 + rand * 0.16;
  out.setRGB(tmp.r * jitter, tmp.g * jitter, tmp.b * jitter);
}
