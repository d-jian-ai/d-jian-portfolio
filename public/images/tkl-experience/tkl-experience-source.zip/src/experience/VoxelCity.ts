import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { PALETTES, pickColor, SKIN_SEQUENCE } from "./palettes";
import {
  TAIKOO_CENTER,
  CENTER_BOUNDS,
  BUILDING_SURFACES,
  BUILDING_THEMES,
  BUILDING_POSITIONS,
  type CenterVoxel,
} from "./taikoo/model";
import { SIGN_PLACEMENTS, SIGN_LABELS } from "./taikoo/signs";
import { TaikooPortal, ChromeSculpture } from "./taikoo/portal";

/** 立面/顶面标牌：正好覆盖 2×2，厚度很薄，平贴在建筑表面 */
const PLAQUE_THICK = 0.16;
/** 悬浮：统一角频率；行程向下 0.7 格、向上 0.3 格 */
const FLOAT_OMEGA = 0.78;
const FLOAT_DOWN = -0.38;
const FLOAT_UP = 0.17;
/** 浮动总幅度恒为一格；下沉量按净空裁剪后，整段行程随之上移 */
const FLOAT_TRAVEL = FLOAT_UP - FLOAT_DOWN;
const PLAQUE_HALF = PLAQUE_THICK / 2;

/**
 * 这几栋楼结构上仍与地面相连，但设计稿里上半部分是浮动的：
 * 3 = 潮玩社区，6 = 智能客服旁同高度那栋，12 = 宇宙中心后方那栋
 */
const FLOAT_TOP_BUILDINGS = new Set([3, 6, 12]);

/**
 * 消散波相位：由离城心的水平距离与高度合成，
 * 中心低处最先消散、外围高处最后消散，形成一圈圈向外扩散的波。
 */
function waveOf(x: number, y: number, z: number) {
  const d = Math.hypot(x, z) / 46; // 归一化到城市半径
  const h = y / 14;
  return Math.min(1, d * 0.72 + h * 0.28);
}

/** 回归基础配色时的临时色 */
const tmpBase = new THREE.Color();

/** mulberry32 种子随机，保证每次刷新城市形态一致 */
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface RingCube {
  base: THREE.Vector3;
  scatterDir: THREE.Vector3;
  angle: number;
  rand: number;
  /** 消散波相位 0..1 */
  wave: number;
}

interface CenterCube extends CenterVoxel {
  scatterDir: THREE.Vector3;
  angle: number;
  /** 悬浮簇编号；-1 = 落地静止（原动画里只有脱离地面的簇在浮动） */
  floatCluster: number;
  /** 消散波相位 0..1：越大越晚消散、越早重现 */
  wave: number;
}

/**
 * 悬浮簇（对照 PPT 远景演示）：
 * 全部使用同一频率、同样的行程（一个方块单位），只有相位彼此错开，
 * 因此各建筑此起彼伏但节奏一致；行程不对称——向下 0.7、向上 0.3。
 */
interface FloatCluster {
  phase: number;
  /** 当前帧的垂直偏移（簇内共享） */
  offset: number;
  /** 本簇的行程下界：按它与正下方静止方块的净空裁剪，避免沉进楼体 */
  down: number;
  /** 行程上界 = down + 一格，总幅度恒定 */
  up: number;
}

interface Building {
  index: number;
  group: THREE.Group;
  mesh: THREE.InstancedMesh;
  cubes: CenterCube[];
  clusters: FloatCluster[];
  hasFloaters: boolean;
}

export interface IconCube {
  id: string;
  label: string;
  /** 标牌所属对象（随建筑浮动），投影标签时取世界坐标 */
  mesh: THREE.Object3D;
  worldPos: THREE.Vector3;
}

/**
 * 城市 = 中心建筑群（用户复原的 12 栋镂空模型，逐栋独立浮动 + 原位立面标牌）
 *      + 环绕楼群（程序化背景，退为衬托：更远、更矮、色彩更淡）
 *      + 中央雕塑（悬浮球 / 光环 / 金色双箭头）
 */
export class VoxelCity {
  group = new THREE.Group();
  icons: IconCube[] = [];

  private buildings: Building[] = [];
  private ringMesh!: THREE.InstancedMesh;
  private ringCubes: RingCube[] = [];
  private dummy = new THREE.Object3D();
  private cubeMat!: THREE.MeshPhysicalMaterial;
  private ringMat!: THREE.MeshPhysicalMaterial;
  /** 星夜贴图混合度 uniform（0=无贴图，1=每块砖一片画） */
  private mapMix = { value: 0 };
  private starryTex: THREE.CanvasTexture | null = null;
  /** 当前主题的逐块明暗抖动强度 */
  private themeVariation = 1;
  /**
   * 回归基础配色的混合度（0=当前联名，1=完全回到晶体玻璃）。
   * 用"当前色 → 基础色"的直接混合，而不是把 skinPos 插值回 0——
   * 后者必然依次经过星夜、波普、蒙德里安，视觉上就是一路回闪。
   */
  private baseReturn = 0;
  /** 尚未加载完的标牌贴图数量；归零时触发预热 */
  private signTexPending = 0;
  /** 标牌贴图全部就绪的回调（Experience 用它做 GPU 预热） */
  onSignTexReady: (() => void) | null = null;
  /** 全部立面标牌（含小号），进出场编排统一管理 */
  private allSigns: THREE.Group[] = [];
  /** 挂在悬浮簇上的标牌，需每帧跟随该簇位移 */
  private floatingSigns: Array<{
    holder: THREE.Group;
    building: Building;
    cluster: number;
    baseY: number;
  }> = [];
  /** 外围建筑的遮挡淡出属性 */
  private ringFadeAttr!: THREE.InstancedBufferAttribute;
  private occFrame = 0;

  private monoMix = 1;
  private skinPos = 0;
  private scatter = 0;
  /** 环绕楼群向背景色的混合度（最初版本是全饱和，默认仅 0.05 极轻降调） */
  private ringWash = 0.05;
  private dirty = { color: true, matrix: true };
  /** 悬浮簇动画总开关（炸开时收零） */
  private floatScale = 1;

  private portal!: TaikooPortal;
  private chrome!: ChromeSculpture;
  /** 中央 4×4 低层建筑（building-11，x -3..0 / z 1..4）的几何中心 */
  private sculptureAnchor = new THREE.Vector3(-1.5, 0, 2.5);

  /**
   * 每个色板的材质性格——数值对照 PPT 各联名效果图定的，不是通用微调：
   *  glass    宝石玻璃：高透射、低粗糙
   *  mondrian 哑光塑料：完全不透明、无清漆、粗糙面（参考图里是柔和的无光泽原色块）
   *  koons    镜面铬：满金属度 + 近乎镜面，环境反射拉满（参考图是全镜面糖果色）
   *  vangogh  哑光颜料 + 笔触凹凸 + 星夜贴图
   *  dior     琥珀金属玻璃：高金属度 + 部分透射，暖金质感
   */
  private static THEME_MAT: Record<
    string,
    {
      metalness: number;
      roughness: number;
      clearcoat: number;
      clearcoatRoughness: number;
      transmission: number;
      thickness: number;
      ior: number;
      envMapIntensity: number;
      bumpScale: number;
      iridescence: number;
      /** 逐块明暗抖动强度：蒙德里安要平整，波普/玻璃可以强一些 */
      variation: number;
    }
  > = {
    glass:    { metalness: 0.0,  roughness: 0.06, clearcoat: 1,    clearcoatRoughness: 0.06, transmission: 0.90, thickness: 0.80, ior: 1.45, envMapIntensity: 1.30, bumpScale: 0,    iridescence: 0.05, variation: 1.0 },
    mondrian: { metalness: 0.0,  roughness: 0.62, clearcoat: 0,    clearcoatRoughness: 0.60, transmission: 0.00, thickness: 0.00, ior: 1.40, envMapIntensity: 0.55, bumpScale: 0,    iridescence: 0.00, variation: 0.25 },
    koons:    { metalness: 1.0,  roughness: 0.025,clearcoat: 1,    clearcoatRoughness: 0.02, transmission: 0.00, thickness: 0.00, ior: 2.40, envMapIntensity: 3.20, bumpScale: 0,    iridescence: 0.85, variation: 0.7 },
    vangogh:  { metalness: 0.04, roughness: 0.70, clearcoat: 0.10, clearcoatRoughness: 0.55, transmission: 0.00, thickness: 0.00, ior: 1.40, envMapIntensity: 0.55, bumpScale: 0.85, iridescence: 0.00, variation: 0.5 },
    dior:     { metalness: 0.82, roughness: 0.09, clearcoat: 1,    clearcoatRoughness: 0.06, transmission: 0.30, thickness: 0.55, ior: 1.70, envMapIntensity: 2.60, bumpScale: 0,    iridescence: 0.12, variation: 0.8 },
  };

  constructor(private densityScale = 1, private lowPerf = false) {
    this.build();
  }

  /* ───────────────────────── 生成 ───────────────────────── */

  private build() {
    const rnd = mulberry32(20230116);
    // 中心建筑：细倒角 + 真折射玻璃（低端设备退回清漆树脂）；换肤时整套材质随主题变形
    const geo = new RoundedBoxGeometry(0.94, 0.94, 0.94, 2, 0.04);
    this.cubeMat = this.lowPerf
      ? new THREE.MeshPhysicalMaterial({
          color: "#ffffff",
          clearcoat: 1,
          clearcoatRoughness: 0.08,
          metalness: 0.05,
          roughness: 0.15,
          envMapIntensity: 1.5,
        })
      : new THREE.MeshPhysicalMaterial({
          color: "#ffffff",
          metalness: 0,
          roughness: 0.06,
          clearcoat: 1,
          clearcoatRoughness: 0.06,
          transmission: 0.9,
          thickness: 0.8,
          ior: 1.45,
          envMapIntensity: 1.3,
          bumpMap: makeBrushBump(),
          bumpScale: 0,
        });
    // 星夜画布延迟挂载：只在接近"星夜"色板时才赋给 map，
    // 否则 USE_MAP 会通过透射通道把纹理漏到其它章节
    this.starryTex = this.lowPerf ? null : makeStarryTexture();
    // "每个砖块不一样"：每个方块采样星夜画布的不同区域（实例化 UV 偏移），
    // 换肤到"星夜"时 uMapMix→1，整片建筑群拼成一幅被打散重组的画
    if (!this.lowPerf) {
      this.cubeMat.onBeforeCompile = (shader) => {
        shader.uniforms.uMapMix = this.mapMix;
        shader.vertexShader = shader.vertexShader
          .replace("#include <common>", "#include <common>\nattribute vec3 aUvRect;")
          .replace(
            "#include <uv_vertex>",
            "#include <uv_vertex>\n#ifdef USE_MAP\n\tvMapUv = vMapUv * aUvRect.z + aUvRect.xy;\n#endif"
          );
        shader.fragmentShader = shader.fragmentShader
          .replace("#include <common>", "#include <common>\nuniform float uMapMix;")
          .replace(
            "#include <map_fragment>",
            "#ifdef USE_MAP\n\tvec4 tklTexel = texture2D( map, vMapUv );\n\tdiffuseColor.rgb = mix( diffuseColor.rgb, tklTexel.rgb, uMapMix );\n#endif"
          );
      };
      this.cubeMat.customProgramCacheKey = () => "tkl-center-starry";
    }
    // 外围楼群：完整保留最初版本的配方——锐边方块 + 半透明宝石玻璃，不随主题变形
    const ringGeo = new THREE.BoxGeometry(0.92, 0.92, 0.92);
    this.ringMat = new THREE.MeshPhysicalMaterial({
      metalness: 0,
      roughness: 0.16,
      transparent: true,
      opacity: 0.85,
      envMapIntensity: 1.05, // 亮度整体压低，衬托中心
      clearcoat: 0.5,
      clearcoatRoughness: 0.25,
    });

    const makeScatterDir = (x: number, z: number) => {
      const dir = new THREE.Vector3(x, 0, z);
      if (dir.lengthSq() < 0.01) dir.set(1, 0, 0);
      dir.normalize();
      return new THREE.Vector3(
        dir.x + (rnd() - 0.5) * 1.2,
        0.6 + rnd() * 1.6,
        dir.z + (rnd() - 0.5) * 1.2
      )
        .normalize()
        .multiplyScalar(20 + rnd() * 32);
    };

    /* ── 中心：12 栋建筑各自成组 ── */
    const byBuilding = new Map<number, CenterVoxel[]>();
    for (const v of TAIKOO_CENTER) {
      const list = byBuilding.get(v.buildingIndex) ?? [];
      list.push(v);
      byBuilding.set(v.buildingIndex, list);
    }
    for (const [index, voxels] of byBuilding) {
      const cubes: CenterCube[] = voxels.map((v) => ({
        ...v,
        scatterDir: makeScatterDir(v.x, v.z),
        angle: Math.atan2(v.z, v.x),
        floatCluster: -1,
        wave: waveOf(v.x, v.y, v.z),
      }));

      /* 悬浮簇分析（对应原 GIF 演示：只有脱离地面的方块簇在浮动）——
         从落地层做 6 邻域连通遍历，未被触达的连通分量即悬浮簇 */
      const key = (x: number, y: number, z: number) => `${x},${y},${z}`;
      const cellIndex = new Map<string, number>();
      cubes.forEach((c, i) => cellIndex.set(key(c.x, c.y - 0.5, c.z), i));
      /* 只有与地面"完全不相连"的方块簇才浮动——即 PPT 里那些上下分离的部分。
         （用"正下方是否有支撑"的严格判定会把实心楼的悬挑也算进来，那是错的。） */
      const dirs = [
        [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
      ];
      const grounded = new Set<number>();
      const queue: number[] = [];
      cubes.forEach((c, i) => {
        if (Math.round(c.y - 0.5) === 0) { grounded.add(i); queue.push(i); }
      });
      while (queue.length) {
        const i = queue.pop()!;
        const c = cubes[i];
        for (const [dx, dy, dz] of dirs) {
          const j = cellIndex.get(key(c.x + dx, c.y - 0.5 + dy, c.z + dz));
          if (j !== undefined && !grounded.has(j)) { grounded.add(j); queue.push(j); }
        }
      }
      const clusters: FloatCluster[] = [];
      const clusterOf = new Map<number, number>();
      const pendingMembers: number[][] = [];
      cubes.forEach((_, i) => {
        if (grounded.has(i) || clusterOf.has(i)) return;
        const cid = clusters.length;
        pendingMembers.push([]);
        // 频率与行程全局统一，只把相位错开，形成此起彼伏的韵律
        clusters.push({ phase: rnd() * Math.PI * 2, offset: 0, down: FLOAT_DOWN, up: FLOAT_UP });
        const bfs = [i];
        clusterOf.set(i, cid);
        pendingMembers[cid].push(i);
        while (bfs.length) {
          const a = bfs.pop()!;
          const c = cubes[a];
          for (const [dx, dy, dz] of dirs) {
            const j = cellIndex.get(key(c.x + dx, c.y - 0.5 + dy, c.z + dz));
            if (j !== undefined && !grounded.has(j) && !clusterOf.has(j)) {
              clusterOf.set(j, cid);
              pendingMembers[cid].push(j);
              bfs.push(j);
            }
          }
        }
      });
      // 太小的簇（1–2 块）会显得零碎抖动，忽略掉
      clusterOf.forEach((cid, i) => {
        if (pendingMembers[cid].length >= 3) cubes[i].floatCluster = cid;
      });

      /* 这几栋的镂空在设计稿里本来就把上下断开了——每一列都有竖向断点，
         只是断点高度各不相同。6 邻域连通遍历会顺着错落的缺口"绕"上去，
         于是误判成与地面相连。改为逐列找该列最高的那处断点，断点以上归入
         同一个悬浮簇：上半部分整体浮动，且每列与下方都留着至少一格空隙。 */
      if (FLOAT_TOP_BUILDINGS.has(index)) {
        const byColumn = new Map<string, number[]>();
        for (const c of cubes) {
          if (c.floatCluster >= 0) continue;
          const k = c.x + "," + c.z;
          const y = Math.round(c.y - 0.5);
          const arr = byColumn.get(k);
          if (arr) arr.push(y);
          else byColumn.set(k, [y]);
        }
        /** 列 → 该列悬浮部分的起始层（该列最高一处断点之上） */
        const floatFrom = new Map<string, number>();
        for (const [k, ys] of byColumn) {
          ys.sort((p, q) => p - q);
          for (let i = ys.length - 1; i > 0; i--)
            if (ys[i] - ys[i - 1] > 1) {
              floatFrom.set(k, ys[i]);
              break;
            }
        }
        // 先收集再落簇：数量不足时直接放弃，不会留下指向已弹出簇的悬空编号
        const picked: number[] = [];
        cubes.forEach((c, i) => {
          if (c.floatCluster >= 0) return;
          const from = floatFrom.get(c.x + "," + c.z);
          if (from !== undefined && Math.round(c.y - 0.5) >= from) picked.push(i);
        });
        /* 兜底：整栋没有任何镂空的实心楼（如 12 号，2×3×7 完整长方体）
           逐列找不到断点，退回"最窄腰线以上整体浮动"。这类楼腰线上下贴合、
           净空为 0，后面的行程裁剪会自动把它改成纯向上浮，同样不会穿模。 */
        if (picked.length < 3) {
          const perY = new Map<number, number>();
          let maxY = 0;
          for (const c of cubes) {
            const y = Math.round(c.y - 0.5);
            perY.set(y, (perY.get(y) ?? 0) + 1);
            if (y > maxY) maxY = y;
          }
          let waist = -1;
          let waistCount = Infinity;
          for (let y = Math.ceil(maxY * 0.45); y <= maxY - 2; y++) {
            const n = perY.get(y) ?? 0;
            if (n > 0 && n < waistCount) {
              waistCount = n;
              waist = y;
            }
          }
          if (waist > 0) {
            picked.length = 0;
            cubes.forEach((c, i) => {
              if (c.floatCluster < 0 && Math.round(c.y - 0.5) > waist) picked.push(i);
            });
          }
        }
        if (picked.length >= 3) {
          const cid = clusters.length;
          clusters.push({ phase: rnd() * Math.PI * 2, offset: 0, down: FLOAT_DOWN, up: FLOAT_UP });
          for (const i of picked) cubes[i].floatCluster = cid;
        }
      }

      /* 行程按"正下方净空"裁剪：总幅度仍是一格，但下沉量不会超过该簇与
         其正下方静止方块之间的空隙。腰线以上整体浮动的那几栋（会员社区、
         智能客服旁那栋、宇宙中心后那栋）净空为 0，因此改为纯向上浮动，
         不再下沉 0.7 格而穿进楼体。真正脱离地面的簇净空为 1，规格不变。 */
      if (clusters.length) {
        const staticCols = new Map<string, number[]>();
        for (const c of cubes) {
          if (c.floatCluster >= 0) continue;
          const k = c.x + "," + c.z;
          const arr = staticCols.get(k);
          if (arr) arr.push(c.y);
          else staticCols.set(k, [c.y]);
        }
        const clear = new Array<number>(clusters.length).fill(Infinity);
        for (const c of cubes) {
          if (c.floatCluster < 0) continue;
          for (const sy of staticCols.get(c.x + "," + c.z) ?? [])
            if (sy < c.y) clear[c.floatCluster] = Math.min(clear[c.floatCluster], c.y - sy - 1);
        }
        for (let i = 0; i < clusters.length; i++) {
          clusters[i].down = -Math.min(-FLOAT_DOWN, Math.max(0, clear[i]));
          clusters[i].up = clusters[i].down + FLOAT_TRAVEL;
        }
      }

      // 每栋建筑克隆几何以携带自己的实例化 UV 区域（星夜贴图的"每块砖一片画"）
      const bGeo = geo.clone();
      const uvRect = new Float32Array(cubes.length * 3);
      for (let i = 0; i < cubes.length; i++) {
        const scale = 0.2 + rnd() * 0.14;
        uvRect[i * 3] = rnd() * (1 - scale);
        uvRect[i * 3 + 1] = rnd() * (1 - scale);
        uvRect[i * 3 + 2] = scale;
      }
      bGeo.setAttribute("aUvRect", new THREE.InstancedBufferAttribute(uvRect, 3));
      const mesh = new THREE.InstancedMesh(bGeo, this.cubeMat, cubes.length);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.instanceColor = new THREE.InstancedBufferAttribute(
        new Float32Array(cubes.length * 3),
        3
      );
      const group = new THREE.Group();
      group.add(mesh);
      this.group.add(group);
      this.buildings.push({
        index,
        group,
        mesh,
        cubes,
        clusters,
        hasFloaters: clusters.length > 0,
      });
    }
    this.buildSigns();

    /* ── 环绕楼群（背景衬托） ── */
    const margin = 7;
    const keepClear = (x: number, z: number) =>
      x > CENTER_BOUNDS.minX - margin &&
      x < CENTER_BOUNDS.maxX + margin &&
      z > CENTER_BOUNDS.minZ - margin &&
      z < CENTER_BOUNDS.maxZ + margin;
    // 俯冲镜头进场走廊：只留一条窄缝，不再切掉整个象限（初版四周是完整环绕的）
    const inCorridor = (x: number, z: number) => x > 2 && x < 15 && z > 18;

    const ringCubes: RingCube[] = [];
    const occupied = new Set<string>();
    const addRingCube = (x: number, y: number, z: number) => {
      const k = `${x},${y},${z}`;
      if (occupied.has(k)) return;
      occupied.add(k);
      ringCubes.push({
        base: new THREE.Vector3(x, y, z),
        scatterDir: makeScatterDir(x, z),
        angle: Math.atan2(z, x),
        rand: rnd(),
        wave: waveOf(x, y, z),
      });
    };

    // 环绕楼群：沿用最初版本的塔楼形态（错落阶梯、彩色玻璃），略高于主建筑群
    const towerCount = Math.round(38 * this.densityScale);
    const placed: { x: number; z: number; r: number }[] = [];
    for (let i = 0; i < towerCount; i++) {
      let cx = 0,
        cz = 0,
        ok = false;
      for (let attempt = 0; attempt < 60 && !ok; attempt++) {
        const ang = rnd() * Math.PI * 2;
        const dist = 24 + rnd() * 18;
        cx = Math.round(Math.cos(ang) * dist);
        cz = Math.round(Math.sin(ang) * dist * 0.9);
        ok =
          !keepClear(cx, cz) &&
          !inCorridor(cx, cz) &&
          placed.every((p) => (p.x - cx) ** 2 + (p.z - cz) ** 2 > (p.r + 3.2) ** 2);
      }
      if (!ok) continue;
      const w = 2 + Math.floor(rnd() * 3);
      const d = 2 + Math.floor(rnd() * 3);
      const distC0 = Math.hypot(cx, cz);
      const hMax = 5 + Math.min(12, Math.round((distC0 - 22) * 0.55 + rnd() * 5));
      placed.push({ x: cx, z: cz, r: Math.max(w, d) });
      for (let ix = 0; ix < w; ix++) {
        for (let iz = 0; iz < d; iz++) {
          const hCol = Math.max(2, Math.round(hMax * (0.55 + rnd() * 0.5)));
          for (let iy = 0; iy < hCol; iy++) {
            if (iy > 1 && rnd() < 0.06) continue;
            addRingCube(cx + ix - Math.floor(w / 2), iy + 0.5, cz + iz - Math.floor(d / 2));
          }
        }
      }
    }
    const platCount = Math.round(14 * this.densityScale);
    for (let i = 0; i < platCount; i++) {
      const ang = rnd() * Math.PI * 2;
      const dist = 23 + rnd() * 16;
      const cx = Math.round(Math.cos(ang) * dist);
      const cz = Math.round(Math.sin(ang) * dist * 0.9);
      if (keepClear(cx, cz) || inCorridor(cx, cz)) continue;
      const w = 1 + Math.floor(rnd() * 3);
      const d = 1 + Math.floor(rnd() * 3);
      for (let ix = 0; ix < w; ix++)
        for (let iz = 0; iz < d; iz++)
          if (rnd() > 0.2) addRingCube(cx + ix, 0.5, cz + iz);
    }
    this.ringCubes = ringCubes;
    // 遮挡淡出：每个外围实例带一个 aFade（1=正常，0=完全透明）
    const fadeArr = new Float32Array(ringCubes.length).fill(1);
    this.ringFadeAttr = new THREE.InstancedBufferAttribute(fadeArr, 1);
    ringGeo.setAttribute("aFade", this.ringFadeAttr);
    this.ringMat.onBeforeCompile = (shader) => {
      shader.vertexShader = shader.vertexShader
        .replace("#include <common>", "#include <common>\nattribute float aFade;\nvarying float vFade;")
        .replace("#include <begin_vertex>", "#include <begin_vertex>\n\tvFade = aFade;");
      shader.fragmentShader = shader.fragmentShader
        .replace("#include <common>", "#include <common>\nvarying float vFade;")
        .replace(
          "#include <dithering_fragment>",
          "#include <dithering_fragment>\n\tgl_FragColor.a *= vFade;"
        );
    };
    this.ringMat.customProgramCacheKey = () => "tkl-ring-fade";
    this.ringMesh = new THREE.InstancedMesh(ringGeo, this.ringMat, ringCubes.length);
    this.ringMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.ringMesh.instanceColor = new THREE.InstancedBufferAttribute(
      new Float32Array(ringCubes.length * 3),
      3
    );
    this.group.add(this.ringMesh);

    this.buildSculpture();
    this.buildGround();

    this.applyMatrices();
    this.applyColors();
    this.setSignsOpacity(0); // 标牌初始隐藏，滚到远景章节才浮现
  }

  /**
   * 立面标牌
   * - 主牌覆盖 2×2、小牌覆盖 1×1，都平贴在建筑外露面上（对照 PPT 效果图）
   * - 朝向在 ±x / ±z 四个水平面里挑：必须外露，并优先朝向镜头常在的前右方
   * - 若挂载处属于悬浮簇，标牌每帧跟随该簇一起浮动
   */
  private buildSigns() {
    const loader = new THREE.TextureLoader();
    const bigGeo = new RoundedBoxGeometry(1.92, 1.92, PLAQUE_THICK, 4, 0.06);
    const smallGeo = new RoundedBoxGeometry(0.94, 0.94, PLAQUE_THICK, 3, 0.04);
    /* transparent 必须在这里就设成 true。它是 THREE 的着色器程序缓存键之一，
       如果留到 applySignAppearance 里才翻转，MeshPhysicalMaterial 这套最贵的
       着色器会在远景章节标牌首次淡入时整批重编译——实测那一帧要 76ms。 */
    const plaqueMat = new THREE.MeshPhysicalMaterial({
      transparent: true,
      opacity: 1,
      clearcoat: 1,
      clearcoatRoughness: 0.08,
      color: "#171311",
      envMapIntensity: 1.55,
      metalness: 0.34,
      roughness: 0.16,
    });

    /**
     * 可挂载的面。原始 SIGN_PLACEMENTS 里带 rotation 的（会员社区/停车服务/会员中心）
     * 本就是顶面牌，只在顶面里选；其余在四个水平面里选，
     * weight 越大表示越朝向镜头常驻的前右方。
     */
    type Face = { nx: number; ny: number; nz: number; weight: number; top?: boolean };
    const SIDE_FACES: Face[] = [
      { nx: 0, ny: 0, nz: 1, weight: 1.0 },
      { nx: 1, ny: 0, nz: 0, weight: 0.85 },
      { nx: -1, ny: 0, nz: 0, weight: 0.25 },
      { nx: 0, ny: 0, nz: -1, weight: 0.15 },
    ];
    const TOP_FACES: Face[] = [{ nx: 0, ny: 1, nz: 0, weight: 1, top: true }];
    const faceRotation = (f: Face) =>
      f.top
        ? new THREE.Euler(-Math.PI / 2, 0, 0)
        : new THREE.Euler(0, Math.atan2(f.nx, f.nz), 0);

    for (const placement of SIGN_PLACEMENTS) {
      const building = this.buildings.find((b) => b.index === placement.buildingIndex);
      if (!building) continue;
      const base = BUILDING_POSITIONS[placement.buildingIndex] ?? { x: 0, y: 0, z: 0 };
      const isSmall = placement.scale < 1;
      const span = isSmall ? 1 : 2; // 覆盖的方块数

      // 该栋楼的占用格 + 所属悬浮簇
      const cellCluster = new Map<string, number>();
      const ck = (x: number, y: number, z: number) =>
        `${Math.round(x)},${Math.round(y)},${Math.round(z)}`;
      for (const c of building.cubes) {
        cellCluster.set(ck(c.x, c.y - 0.5, c.z), c.floatCluster);
      }
      const filled = (x: number, y: number, z: number) => cellCluster.has(ck(x, y, z));

      const wx0 = base.x + placement.localPosition[0];
      const wy0 = base.y + placement.localPosition[1];
      const wz0 = base.z + placement.localPosition[2];

      /* 候选偏移：2×2 牌挂在四格公共角点（±0.5），1×1 牌挂在单格中心（0） */
      const offs: number[] = span === 2 ? [-0.5, 0.5] : [0];
      const quad: Array<[number, number]> =
        span === 2 ? [[-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]] : [[0, 0]];

      let best = Infinity;
      let chosen: {
        x: number; y: number; z: number; face: Face; cluster: number;
      } | null = null;

      // 原数据带 rotation 的是顶面牌，只在顶面里找
      const candidates = placement.rotation ? TOP_FACES : SIDE_FACES;

      for (const face of candidates) {
        for (const c of building.cubes) {
          const cy = Math.round(c.y - 0.5);
          // 该格在此朝向上必须外露
          if (filled(c.x + face.nx, cy + face.ny, c.z + face.nz)) continue;
          for (const oa of offs) {
            for (const ob of offs) {
              /* 面内的两个轴：顶面是 x/z，立面是 (水平轴)/y */
              const ax = face.top ? c.x + oa : face.nz !== 0 ? c.x + oa : c.x;
              const az = face.top ? c.z + ob : face.nx !== 0 ? c.z + oa : c.z;
              const ay = face.top ? cy : cy + ob;
              // 2×2 立面牌的最低合法中心是 0.5（覆盖 y=0、1），低矮楼全靠它
              if (!face.top && ay < (isSmall ? 0 : 0.5)) continue;
              // 覆盖范围内每一格都要存在、且都朝该方向外露
              let ok = true;
              let cluster = -2;
              for (const [du, dv] of quad) {
                const qx = face.top ? ax + du : face.nz !== 0 ? ax + du : ax;
                const qz = face.top ? az + dv : face.nx !== 0 ? az + du : az;
                const qy = face.top ? ay : ay + dv;
                if (
                  !filled(qx, qy, qz) ||
                  filled(qx + face.nx, qy + face.ny, qz + face.nz)
                ) {
                  ok = false;
                  break;
                }
                const cl = cellCluster.get(ck(qx, qy, qz)) ?? -1;
                if (cluster === -2) cluster = cl;
                else if (cluster !== cl) { ok = false; break; } // 不能横跨两个运动状态
              }
              if (!ok) continue;
              // 越接近原设计位置、越朝向镜头，得分越低；顶面牌额外偏好更高的楼层
              const d =
                (ax - wx0) ** 2 + (ay - wy0) ** 2 + (az - wz0) ** 2 +
                (1 - face.weight) * 26 +
                (face.top ? -ay * 1.2 : 0);
              if (d < best) {
                best = d;
                chosen = { x: ax, y: ay, z: az, face, cluster };
              }
            }
          }
        }
      }
      if (!chosen) continue;

      /* 方块中心 =(x, cellY+0.5, z)、半边长 0.47；面板平贴其外表面并微微凸出 */
      const face = chosen.face;
      const holder = new THREE.Group();
      holder.position.set(
        chosen.x + face.nx * (0.47 + PLAQUE_HALF),
        chosen.y + 0.5 + face.ny * (0.47 + PLAQUE_HALF),
        chosen.z + face.nz * (0.47 + PLAQUE_HALF)
      );
      holder.rotation.copy(faceRotation(face));

      holder.add(new THREE.Mesh(isSmall ? smallGeo : bigGeo, plaqueMat));

      this.signTexPending++;
      const tex = loader.load(placement.url, () => {
        // 贴图是异步到的：全部到齐后才预热，否则 compile 时纹理还是空的
        if (--this.signTexPending === 0) this.onSignTexReady?.();
      }, undefined, () => {
        if (--this.signTexPending === 0) this.onSignTexReady?.();
      });
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 8;
      const glyph = new THREE.Mesh(
        new THREE.PlaneGeometry(isSmall ? 0.74 : 1.5, isSmall ? 0.74 : 1.5),
        new THREE.MeshBasicMaterial({
          map: tex,
          alphaTest: 0.05,
          transparent: true,
          toneMapped: false,
          polygonOffset: true,
          polygonOffsetFactor: -2,
        })
      );
      glyph.position.z = PLAQUE_THICK / 2 + 0.004;
      holder.add(glyph);
      // 记下挂载方块的波相位：标牌要和它所在的那批方块同时消散，
      // 而不是等全城消散过半后统一 pop 掉（否则牌子会悬在空气里）
      holder.userData.wave = waveOf(chosen.x, chosen.y, chosen.z);
      // 调试用：记下最终挂载格与朝向，便于核对牌子落在楼体的哪一面哪一格
      holder.userData.mount = { kind: placement.kind, scale: placement.scale,
        cell: [chosen.x, chosen.y, chosen.z], n: [face.nx, face.ny, face.nz] };
      building.group.add(holder);
      this.allSigns.push(holder);

      // 挂载处若属于悬浮簇，标牌每帧跟随该簇上下浮动
      if (chosen.cluster >= 0) {
        this.floatingSigns.push({
          holder,
          building,
          cluster: chosen.cluster,
          baseY: holder.position.y,
        });
      }

      // 只有主牌配浮动文字标签；小牌是近景补充，会员码只保留立面标牌
      if (!isSmall && placement.kind !== "login") {
        this.icons.push({
          id: `${placement.kind}-${placement.buildingIndex}`,
          label: SIGN_LABELS[placement.kind],
          mesh: holder,
          // 标签固定在挂载基准点：牌子会随簇浮动，但文字标签保持稳定
          worldPos: holder.position.clone(),
        });
      }
    }
  }

  private buildSculpture() {
    // 飞行器与铬雕塑垂直叠放在中央 4×4 建筑正上方：基座 → 铬雕塑 → 悬浮门户
    this.portal = new TaikooPortal(this.sculptureAnchor, 8.6);
    this.group.add(this.portal.group);
    this.chrome = new ChromeSculpture(
      new THREE.Vector3(this.sculptureAnchor.x, 3.5, this.sculptureAnchor.z),
      new THREE.Vector3(1.6, 1.4, 1.0)
    );
    this.group.add(this.chrome.mesh);
    this.portalWave = waveOf(this.sculptureAnchor.x, 8.6, this.sculptureAnchor.z);
    this.chromeWave = waveOf(this.sculptureAnchor.x, 3.5, this.sculptureAnchor.z);
  }

  private groundMat!: THREE.MeshStandardMaterial;
  private buildGround() {
    this.groundMat = new THREE.MeshStandardMaterial({
      color: PALETTES.mono.ground,
      roughness: 0.95,
      metalness: 0,
    });
    const ground = new THREE.Mesh(new THREE.CircleGeometry(120, 64), this.groundMat);
    ground.rotation.x = -Math.PI / 2;
    this.group.add(ground);
  }

  /* ───────────────────────── 状态驱动 ───────────────────────── */

  setMonoMix(v: number) {
    v = THREE.MathUtils.clamp(v, 0, 1);
    if (Math.abs(v - this.monoMix) < 0.004) return;
    this.monoMix = v;
    this.dirty.color = true;
    this.updateStarryMix(); // 素体阶段必须同步压掉星夜贴图
  }

  setBaseReturn(v: number) {
    v = THREE.MathUtils.clamp(v, 0, 1);
    if (Math.abs(v - this.baseReturn) < 0.004) return;
    this.baseReturn = v;
    this.dirty.color = true;
    this.applyThemeMaterial();
    this.updateStarryMix();
  }

  setSkinPos(v: number) {
    v = THREE.MathUtils.clamp(v, 0, SKIN_SEQUENCE.length - 1);
    if (Math.abs(v - this.skinPos) < 0.004) return;
    this.skinPos = v;
    this.dirty.color = true;
    this.applyThemeMaterial();
    this.updateStarryMix();
  }

  /**
   * 星夜贴图的实际混合度 = 色板接近度 × (1 - 单色度)。
   * 必须乘上单色度：否则滚回首页时城市已恢复单色白，
   * 贴图却仍满混合，墙面会残留星夜花纹。
   */
  private updateStarryMix() {
    const skinMix = Math.max(0, 1 - Math.abs(this.skinPos - 3));
    const eff = skinMix * (1 - this.monoMix) * (1 - this.baseReturn);
    this.mapMix.value = eff;
    // 贴图只在真正需要时挂载，避免从透射通道漏到其它章节
    const want = eff > 0.001 ? this.starryTex : null;
    if (this.cubeMat.map !== want) {
      this.cubeMat.map = want;
      this.cubeMat.needsUpdate = true;
    }
  }

  /** 材质随色板插值：换的不只是颜色，还有整套材质性格 */
  private applyThemeMaterial() {
    if (this.lowPerf) return;
    const idx = Math.floor(this.skinPos);
    const frac = this.skinPos - idx;
    const a = VoxelCity.THEME_MAT[SKIN_SEQUENCE[idx]];
    const b = VoxelCity.THEME_MAT[SKIN_SEQUENCE[Math.min(idx + 1, SKIN_SEQUENCE.length - 1)]];
    const g = VoxelCity.THEME_MAT.glass;
    const r = this.baseReturn;
    // 先在相邻两个联名之间插值，再整体混回基础材质
    const L = (x: number, y: number) => {
      const v = x + (y - x) * frac;
      return v + (0 - v) * 0; // 占位，实际混合在 LB 里
    };
    const LB = (k: keyof typeof g) => {
      const v = L(a[k] as number, b[k] as number);
      return v + ((g[k] as number) - v) * r;
    };
    void L;
    const m = this.cubeMat;
    m.metalness = LB("metalness");
    m.roughness = LB("roughness");
    m.clearcoat = LB("clearcoat");
    m.clearcoatRoughness = LB("clearcoatRoughness");
    m.transmission = LB("transmission");
    m.envMapIntensity = LB("envMapIntensity");
    m.bumpScale = LB("bumpScale");
    m.thickness = LB("thickness");
    m.ior = LB("ior");
    m.iridescence = LB("iridescence");
    m.iridescenceIOR = 1.9;
    const nextVar = LB("variation");
    if (Math.abs(nextVar - this.themeVariation) > 0.01) {
      this.themeVariation = nextVar;
      this.dirty.color = true;
    }
  }

  setScatter(v: number) {
    this.scrollScatter = THREE.MathUtils.clamp(v, 0, 1);
    this.applyScatter();
  }

  /**
   * 转场专用的散开通道（回到顶部时使用）。
   * 与滚动驱动的散开取最大值——这样滚动位置被重置时，
   * 章节回调写入的 0 不会把转场动画打断。
   */
  setTransitionScatter(v: number) {
    this.transitionScatter = THREE.MathUtils.clamp(v, 0, 1);
    this.applyScatter();
  }

  private scrollScatter = 0;
  private transitionScatter = 0;
  /** 消散度（0=实体，1=完全消失）。转场时用它把跳转藏进画面真空里 */
  private dissolve = 0;
  /**
   * 波纹式消散（0=实体，1=全部消失）。
   * 方块沿"离城心距离 + 高度"合成的波相位依次升空、缩小、消融；
   * 反向播放即为由外向内逐层落回重建。转场的跳转藏在全消散的那一刻。
   */
  setDissolve(v: number) {
    v = THREE.MathUtils.clamp(v, 0, 1);
    if (Math.abs(v - this.dissolve) < 0.002) return;
    this.dissolve = v;
    this.dirty.matrix = true;
    /* 雕塑按自身所在位置的波相位退场，和脚下那批方块同步，
       而不是从消散一开始就整体缩小。 */
    for (const [obj, wave] of [
      [this.portal.group, this.portalWave] as const,
      [this.chrome.mesh, this.chromeWave] as const,
    ]) {
      const s = 1 - this.localDissolve(wave);
      obj.visible = s > 0.01;
      obj.scale.setScalar(Math.max(0.001, s));
    }
    this.applySignAppearance();
  }

  /** 雕塑各自的消散波相位（构造后一次算定） */
  private portalWave = 0;
  private chromeWave = 0;

  /** 单个方块的实际消散度：全局进度减去它自己的波相位延迟 */
  private localDissolve(wave: number) {
    if (this.dissolve <= 0) return 0;
    const SPREAD = 0.78; // 波的宽度：越大波纹拖得越长、空窗越短
    const t = (this.dissolve - wave * SPREAD) / (1 - SPREAD);
    return t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t);
  }

  private applyScatter() {
    const v = Math.max(this.scrollScatter, this.transitionScatter);
    if (Math.abs(v - this.scatter) < 0.003) return;
    this.scatter = v;
    this.dirty.matrix = true;
    this.floatScale = 1 - v; // 炸开时悬浮动画收零
  }

  /** 环绕楼群向背景的混合度：0 = 满色（换肤章节），0.3 = 默认衬托 */
  setRingWash(v: number) {
    v = THREE.MathUtils.clamp(v, 0, 0.8);
    if (Math.abs(v - this.ringWash) < 0.01) return;
    this.ringWash = v;
    this.dirty.color = true;
  }

  getSkinPos() {
    return this.skinPos;
  }

  private lastTime = 0;
  update(time: number) {
    const dt = Math.min(time - this.lastTime, 0.05) || 0.016;
    this.lastTime = time;
    if (this.dirty.matrix) {
      this.applyMatrices();
      this.dirty.matrix = false;
    }
    if (this.dirty.color) {
      this.applyColors();
      this.dirty.color = false;
    }
    // 悬浮簇动画：只有脱离地面的方块簇在缓缓浮动（对应原 GIF 演示）
    // 散开期间必须让位给 applyMatrices，否则悬浮簇会被每帧写回原位（看起来"不散开"）
    if (this.scatter < 0.001 && this.floatScale > 0.01) {
      for (const b of this.buildings) {
        if (!b.hasFloaters) continue;
        for (const cl of b.clusters) {
          // sin ∈ [-1,1] → 行程 [down, up]（总幅度恒一格，下界按净空裁剪）
          const s01 = (Math.sin(time * FLOAT_OMEGA + cl.phase) + 1) * 0.5;
          cl.offset = (cl.down + (cl.up - cl.down) * s01) * this.floatScale;
        }
        for (let i = 0; i < b.cubes.length; i++) {
          const c = b.cubes[i];
          if (c.floatCluster < 0) continue;
          this.dummy.position.set(c.x, c.y + b.clusters[c.floatCluster].offset, c.z);
          this.dummy.rotation.set(0, 0, 0);
          const ldf = this.localDissolve(c.wave);
          this.dummy.position.y += ldf * 7;
          this.dummy.scale.setScalar(Math.max(0.0001, 1 - ldf));
          this.dummy.updateMatrix();
          b.mesh.setMatrixAt(i, this.dummy.matrix);
        }
        b.mesh.instanceMatrix.needsUpdate = true;
      }
      // 挂在悬浮簇上的标牌同步位移，避免牌子留在原地、方块飘走
      for (const fs2 of this.floatingSigns) {
        fs2.holder.position.y = fs2.baseY + fs2.building.clusters[fs2.cluster].offset;
      }
    }
    // 飞行器与铬雕塑
    this.portal.update(time);
    this.chrome.update(time, dt);
  }

  private occV = new THREE.Vector3();
  private occDir = new THREE.Vector3();
  /**
   * 遮挡淡出：位于相机与主体建筑群之间、且贴近视线中轴的外围方块降低不透明度，
   * 让镜头环绕时主体始终可见。每 3 帧算一次，结果做时间平滑避免闪烁。
   */
  updateOcclusion(camPos: THREE.Vector3, target: THREE.Vector3) {
    if (!this.ringFadeAttr) return;
    if (this.occFrame++ % 3 !== 0) return;
    this.occDir.copy(target).sub(camPos);
    const camToTarget = this.occDir.length();
    if (camToTarget < 0.001) return;
    this.occDir.divideScalar(camToTarget);
    const arr = this.ringFadeAttr.array as Float32Array;
    let changed = false;
    for (let i = 0; i < this.ringCubes.length; i++) {
      const base = this.ringCubes[i].base;
      this.occV.copy(base).sub(camPos);
      const along = this.occV.dot(this.occDir);
      let want = 1;
      // 只处理位于相机与主体之间的方块
      if (along > 1 && along < camToTarget - 6) {
        // 到视线中轴的垂直距离
        const perp = Math.sqrt(Math.max(0, this.occV.lengthSq() - along * along));
        // 视锥随距离张开：近处判定半径小，远处大
        const radius = 7 + along * 0.22;
        if (perp < radius) {
          const edge = THREE.MathUtils.clamp(perp / radius, 0, 1);
          want = 0.12 + 0.88 * edge * edge;
        }
      }
      const cur = arr[i];
      if (Math.abs(cur - want) > 0.004) {
        arr[i] = cur + (want - cur) * 0.22; // 时间平滑
        changed = true;
      }
    }
    if (changed) this.ringFadeAttr.needsUpdate = true;
  }

  private applyMatrices() {
    const s = this.scatter;
    const ease = s * s * (3 - 2 * s);
    for (const b of this.buildings) {
      for (let i = 0; i < b.cubes.length; i++) {
        const c = b.cubes[i];
        this.dummy.position.set(
          c.x + c.scatterDir.x * ease,
          c.y + c.scatterDir.y * ease,
          c.z + c.scatterDir.z * ease
        );
        const rot = ease * (c.variation - 0.9) * 20;
        this.dummy.rotation.set(rot, rot * 1.3, rot * 0.7);
        const ld = this.localDissolve(c.wave);
        if (ld > 0) {
          this.dummy.position.y += ld * 7; // 消散时向上飘升
          this.dummy.scale.setScalar(Math.max(0.0001, 1 - ld));
        } else {
          this.dummy.scale.setScalar(1);
        }
        this.dummy.updateMatrix();
        b.mesh.setMatrixAt(i, this.dummy.matrix);
      }
      b.mesh.instanceMatrix.needsUpdate = true;
    }
    for (let i = 0; i < this.ringCubes.length; i++) {
      const c = this.ringCubes[i];
      this.dummy.position.set(
        c.base.x + c.scatterDir.x * ease,
        c.base.y + c.scatterDir.y * ease,
        c.base.z + c.scatterDir.z * ease
      );
      const rot = ease * (c.rand - 0.5) * 4;
      this.dummy.rotation.set(rot, rot * 1.3, rot * 0.7);
      const ldr = this.localDissolve(c.wave);
      if (ldr > 0) {
        this.dummy.position.y += ldr * 7;
        this.dummy.scale.setScalar(Math.max(0.0001, 1 - ldr));
      } else {
        this.dummy.scale.setScalar(1);
      }
      this.dummy.updateMatrix();
      this.ringMesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.ringMesh.instanceMatrix.needsUpdate = true;
  }

  private cA = new THREE.Color();
  private cB = new THREE.Color();
  private cM = new THREE.Color();
  private bgMix = new THREE.Color("#f1f1ef");

  /** 中心建筑某一色板下的目标色 */
  private centerColor(c: CenterCube, skinName: string, out: THREE.Color) {
    const v = 1 + (c.variation - 0.92) * this.themeVariation;
    if (skinName === "glass") {
      out.set(BUILDING_SURFACES[c.buildingIndex]);
    } else if (skinName === "vangogh") {
      // 星夜：底色近中性，画面交给贴图
      out.set("#c8d0da");
    } else {
      const colors = BUILDING_THEMES[skinName];
      out.set(colors[(c.buildingIndex - 1) % colors.length]);
    }
    if (this.baseReturn > 0.001) {
      // 直接混到该栋楼的基础表面色，不经过任何中间联名
      tmpBase.set(BUILDING_SURFACES[c.buildingIndex]);
      out.lerp(tmpBase, this.baseReturn);
    }
    out.multiplyScalar(v);
  }

  private applyColors() {
    const idx = Math.floor(this.skinPos);
    const frac = this.skinPos - idx;
    const nameA = SKIN_SEQUENCE[idx];
    const nameB = SKIN_SEQUENCE[Math.min(idx + 1, SKIN_SEQUENCE.length - 1)];
    const mono = PALETTES.mono;

    for (const b of this.buildings) {
      const attr = b.mesh.instanceColor!;
      for (let i = 0; i < b.cubes.length; i++) {
        const c = b.cubes[i];
        this.centerColor(c, nameA, this.cA);
        if (frac > 0.001) {
          this.centerColor(c, nameB, this.cB);
          this.cA.lerp(this.cB, frac);
        }
        if (this.monoMix > 0.001) {
          // 素体阶段：中心建筑亮暖白，与外围的暗冷灰拉开明度差
          pickColor(mono, c.angle, c.variation, this.cM);
          this.cM.lerp(gB.set("#fffdf6"), 0.72);
          this.cM.multiplyScalar(1.02 + c.variation * 0.06);
          this.cA.lerp(this.cM, this.monoMix);
        }
        attr.setXYZ(i, this.cA.r, this.cA.g, this.cA.b);
      }
      attr.needsUpdate = true;
    }

    // 环绕楼群：同色板但向背景色靠 45%，退为衬托
    const ringAttr = this.ringMesh.instanceColor!;
    for (let i = 0; i < this.ringCubes.length; i++) {
      const c = this.ringCubes[i];
      pickColor(PALETTES[nameA], c.angle, c.rand, this.cA);
      if (frac > 0.001) {
        pickColor(PALETTES[nameB], c.angle, c.rand, this.cB);
        this.cA.lerp(this.cB, frac);
      }
      if (this.baseReturn > 0.001) {
        // 外围与中心同步回到基础色板，否则会出现"中心已恢复、四周还留着香槟金"
        pickColor(PALETTES.glass, c.angle, c.rand, this.cB);
        this.cA.lerp(this.cB, this.baseReturn);
      }
      this.cA.lerp(this.bgMix, this.ringWash);
      this.cA.multiplyScalar(0.84); // 外围整体压暗一档
      if (this.monoMix > 0.001) {
        // 素体阶段：外围压成暗冷灰，与暖白的中心区分开
        pickColor(mono, c.angle, c.rand, this.cM);
        this.cM.lerp(gB.set("#c8ccd4"), 0.5);
        this.cM.multiplyScalar(0.72);
        this.cA.lerp(this.cM, this.monoMix);
      }
      ringAttr.setXYZ(i, this.cA.r, this.cA.g, this.cA.b);
    }
    ringAttr.needsUpdate = true;
  }

  /** 标牌整体透明度（初始隐藏，远景章节才浮现）。管理全部标牌，含小号 */
  private signsOpacity = 1;

  /**
   * 预热标牌：加载阶段就把贴图和着色器推上 GPU。
   * 标牌在前四章全程 visible=false，不预热的话会在远景章节第一次显形时
   * 集中上传十几张贴图并编译材质——实测那一帧要 75ms，就是交界处的卡顿。
   */
  warmUpSigns(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera) {
    const prev = this.allSigns.map((s) => s.visible);
    for (const s of this.allSigns) {
      s.visible = true;
      s.traverse((o) => {
        const m = (o as THREE.Mesh).material as (THREE.Material & { map?: THREE.Texture }) | undefined;
        if (m && m.map) renderer.initTexture(m.map);
      });
    }
    renderer.compile(scene, camera);
    /* 预热完再关掉着色器错误检查：getProgramInfoLog 每次链接程序都会同步
       等 GPU 回话，实测占那一帧的 16ms。启动期保持开启，真有编译错误照样能看到。 */
    renderer.debug.checkShaderErrors = false;
    this.allSigns.forEach((s, i) => (s.visible = prev[i]));
  }

  setSignsOpacity(v: number) {
    v = THREE.MathUtils.clamp(v, 0, 1);
    if (Math.abs(v - this.signsOpacity) < 0.01) return;
    this.signsOpacity = v;
    this.applySignAppearance();
  }

  /**
   * 标牌外观的唯一出口：章节整体透明度 × 各自的波纹消散度。
   * 两者相乘，所以牌子既会随远景章节浮现，也会跟着自己脚下那批方块一起消失。
   */
  private applySignAppearance() {
    for (const holder of this.allSigns) {
      const base = (holder.userData.baseScale ??= holder.scale.x);
      const ld = this.localDissolve((holder.userData.wave as number) ?? 0);
      const v = this.signsOpacity * (1 - ld);
      holder.visible = v > 0.02;
      if (!holder.visible) continue;
      holder.scale.setScalar(Math.max(0.001, base * (0.6 + 0.4 * this.signsOpacity) * (1 - ld)));
      holder.traverse((obj) => {
        const m = (obj as THREE.Mesh).material as THREE.Material | undefined;
        // 只改 opacity：transparent 已在建材质时定好，这里再动会触发重编译
        if (m && "opacity" in m) (m as THREE.Material & { opacity: number }).opacity = v;
      });
    }
  }
}

const gB = new THREE.Color();

/** 程序生成的"星夜"风画布：深蓝夜空 + 旋涡笔触 + 金黄星点，供每块砖采样不同区域 */
function makeStarryTexture(): THREE.CanvasTexture {
  const s = 1024;
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  let seed = 18890615; // 星夜完成年月
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  // 夜空底
  const bg = ctx.createLinearGradient(0, 0, 0, s);
  bg.addColorStop(0, "#152a52");
  bg.addColorStop(0.55, "#1c3a66");
  bg.addColorStop(1, "#122040");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, s, s);
  // 旋涡笔触：多层弧线，蓝青为主，点缀黄
  const strokes = ["#27498a", "#3a64ad", "#5b8ac8", "#7fa8d8", "#2c3f75", "#d9c65a"];
  ctx.lineCap = "round";
  for (let i = 0; i < 1400; i++) {
    const cx = rnd() * s;
    const cy = rnd() * s;
    const r = 6 + rnd() * 46;
    const a0 = rnd() * Math.PI * 2;
    const a1 = a0 + 0.5 + rnd() * 1.4;
    const c = strokes[Math.floor(rnd() * (rnd() < 0.84 ? 5 : 6))];
    ctx.strokeStyle = c;
    ctx.globalAlpha = 0.5 + rnd() * 0.5;
    ctx.lineWidth = 3 + rnd() * 7;
    ctx.beginPath();
    ctx.arc(cx, cy, r, a0, a1);
    ctx.stroke();
  }
  // 星与月：金黄旋涡亮斑
  ctx.globalAlpha = 1;
  for (let i = 0; i < 26; i++) {
    const cx = rnd() * s;
    const cy = rnd() * s * 0.85;
    const r = 14 + rnd() * 30;
    const glow = ctx.createRadialGradient(cx, cy, 1, cx, cy, r * 2.2);
    glow.addColorStop(0, "rgba(244,224,130,0.95)");
    glow.addColorStop(0.4, "rgba(230,196,90,0.5)");
    glow.addColorStop(1, "rgba(230,196,90,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#f0dc8a";
    ctx.lineWidth = 3;
    for (let k = 0; k < 3; k++) {
      ctx.globalAlpha = 0.7 - k * 0.2;
      ctx.beginPath();
      ctx.arc(cx, cy, r * (0.5 + k * 0.35), rnd() * 6, rnd() * 6 + 4);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

/** 梵高笔触凹凸贴图：随机弧线笔划，换肤到"星夜"时 bumpScale 淡入 */
function makeBrushBump(): THREE.CanvasTexture {
  const s = 256;
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = s;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#808080";
  ctx.fillRect(0, 0, s, s);
  let seed = 20230116;
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  for (let i = 0; i < 90; i++) {
    const x = rnd() * s;
    const y = rnd() * s;
    const r = 14 + rnd() * 36;
    const a0 = rnd() * Math.PI * 2;
    const a1 = a0 + 0.7 + rnd() * 1.6;
    const tone = 96 + Math.floor(rnd() * 96);
    ctx.strokeStyle = `rgb(${tone},${tone},${tone})`;
    ctx.lineWidth = 2.5 + rnd() * 4;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.arc(x, y, r, a0, a1);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  return tex;
}
