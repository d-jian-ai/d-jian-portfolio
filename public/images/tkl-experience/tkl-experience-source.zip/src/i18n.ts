export type TklLocale = "zh" | "en" | "fr";

const EN: Record<string, string> = {
  "数字街区 · 未来软件猜想": "Digital Block · A vision of future software",
  "返回作品列表": "Back to work",
  "章节导航": "Chapter navigation",
  "数字街区": "Digital Block",
  "2023 · 空间化界面实验": "2023 · Spatial interface experiment",
  "从一片街区开始": "It began with a city block",
  "它的原型，是北京一片由立方体建筑组成的开放式街区。店铺沿街生长，人群在楼宇之间穿行：\"逛\"这件事，本身就是空间里的体验。": "Its starting point was an open city block in Beijing, built from cubic volumes. Shops line the streets and people move between buildings. Wandering is already a spatial experience.",
  "2023 年，一次难得不设限的机会落在我们手里：不必先算成本，不必迁就现成的方案。于是我们决定，把这种在楼宇之间穿行的体验，原样搬进屏幕。": "In 2023, we were given a rare brief without fixed limits. We did not have to begin with cost or an existing solution, so we brought the experience of moving between buildings directly onto the screen.",
  "街区实景 · 白天": "The district by day",
  "街区实景 · 夜景": "The district at night",
  "开放式街区 · 楼宇之间的动线": "Open district · Paths between buildings",
  "立方体建筑群 · 概念的原点": "Cubic architecture · The origin of the concept",
  "建筑 → 体素": "Architecture → voxels",
  "把街区的立方体建筑拆到最小单位，再用色彩、光和呼吸感重新堆起来。熟悉的空间秩序还在，材质和逻辑已经完全是数字的。": "We reduced the district's cubic architecture to its smallest units, then rebuilt it with colour, light, and rhythm. The familiar spatial order remains, while its material and logic become entirely digital.",
  "远看是一座城市；走近了，每一块都是一个入口。": "From afar it is a city. Up close, every block becomes an entrance.",
  "开屏动画 · 从像素到色彩": "Opening sequence · From pixels to colour",
  "开屏 · 进化之路": "Opening · A path of evolution",
  "按下开屏，画面从黑白像素开始生长，一路快进到色彩鲜明。这是向一款老游戏的致敬，也是项目想说的第一句话：": "The opening grows from monochrome pixels and fast-forwards into vivid colour. It is a tribute to an old game and the project's first statement:",
  "设计从像素时代一路进化到今天，而它还想继续向前。双箭头，就是那记快进键。": "Design has evolved from the pixel era to today, and it still wants to move forward. The double arrow is its fast-forward key.",
  "远景 · 一眼看全": "Far view · Everything at a glance",
  "站在街区上空，功能一览无余：停车、积分、会员、客服、社区。它们不是列表里的条目，而是挂在建筑上的招牌。": "From above the district, parking, points, membership, support, and community are visible at a glance. They are not list items but signs attached to buildings.",
  "你不是在\"找功能\"，你是在\"认路\"。": "You are not finding features. You are learning the place.",
  "全局导航 · 一眼看全": "Global navigation · Everything at a glance",
  "即点即达 · 无需层层进入": "Direct access · No nested menus",
  "远景 ⇄ 近景 · 一键切换": "Far ⇄ near · One-tap switch",
  "首页远景 · 动态演示": "Home far view · Live demo",
  "远景 · 实机演示": "Far view · Live demo",
  "首页近景 · 动态演示": "Home near view · Live demo",
  "近景 · 实机演示": "Near view · Live demo",
  "近景 · 走进去": "Near view · Step inside",
  "视角落下来，城市变成空间。雕塑、悬浮球、楼宇之间的缝隙：功能入口成了可以走近、可以触摸的场景。": "As the viewpoint descends, the city becomes a place. Sculptures, floating forms, and gaps between buildings turn feature entry points into scenes you can approach and touch.",
  "空间俯冲 · 从俯瞰到置身其中": "Spatial dive · From overview to immersion",
  "沉浸交互 · 功能即场景": "Immersive interaction · Features become scenes",
  "换一种色彩": "Change the colour",
  "就是另一座城": "and it becomes another city",
  "蒙德里安的原色、波普的糖果、星夜的蓝与金、高定的香槟：同一座街区，在不同的艺术语言里醒来。城市不必重建，联名可以一直生长。": "Mondrian primaries, pop candy, the blue and gold of a starry night, couture champagne: the same district wakes in different visual languages. The city stays in place while collaborations keep growing.",
  "滚动切换，或点击下方色卡。": "Scroll to switch, or select a palette below.",
  "晶体 · 光学玻璃": "Crystal · Optical glass",
  "蒙德里安 · 原色构成": "Mondrian · Primary composition",
  "波普 · 镜面糖果": "Pop · Mirrored candy",
  "星夜 · 蓝与金": "Starry night · Blue and gold",
  "高定 · 金香槟": "Couture · Golden champagne",
  "接到现实上": "Connect it to reality",
  "把导航接到实景上，路径变成可以看见的东西。体素语言可以一直长下去：新的活动、新的季节、新的联名。": "Connect navigation to the physical world and the route becomes visible. The voxel language can keep growing through new events, seasons, and collaborations.",
  "AR 实景导航": "AR navigation",
  "持续演进": "Continuous evolution",
  "体素语言的持续演进": "The voxel language keeps evolving",
  "2023 · 后记": "2023 · Afterword",
  "一份写给未来的草稿": "A draft addressed to the future",
  "那一年的许多个深夜，办公室的灯一直亮着，笑声也没停过。没有人谈成本，没有人谈边界：我们只是想看看，软件还能长成什么样子。": "Through many late nights that year, the office lights stayed on and the laughter never stopped. Nobody talked about cost or boundaries. We only wanted to see what software could become.",
  "后来我常常想起它：想起页面可以是场所，功能可以是风景，想起一群人把天马行空当作日常的那段时间。": "I still think about it: pages becoming places, features becoming landscapes, and a group of people who treated wild ideas as part of everyday work.",
  "双箭头的意思是\"快进\"。它至今仍指着前方。": "The double arrow means fast-forward. It still points ahead.",
  "回到街区上空 ↑": "Return above the district ↑",
  "2023 · 一次不设限的提案 · 一座可以走进去的城市": "2023 · An open brief · A city you can enter",
  "如果软件不再是一张张页面，而是一座可以走进去的城市，会是什么样子？": "What if software stopped behaving like pages and became a city you could enter?",
  "向下滚动，进入街区": "Scroll down to enter the district",
  "界面落地": "Making the interface real",
  "概念要能落地才算成立。从首页到会员、积分、停车，每一屏都在同一套体素语言里，该有的效率一点没少。": "A concept only works when it can ship. From home to membership, points, and parking, every screen shares the same voxel language without losing efficiency.",
  "首页 · 远景": "Home · Far view",
  "首页 · 近景": "Home · Near view",
  "会员码 · 远景": "Member code · Far view",
  "会员码 · 近景": "Member code · Near view",
  "活动 · 远景": "Events · Far view",
  "活动 · 近景": "Events · Near view",
  "会员中心": "Member centre",
  "会员信息编辑": "Edit member profile",
  "会员 · 信息编辑": "Member · Edit profile",
  "积分兑换": "Points exchange",
  "积分记录": "Points history",
  "积分 · 兑换记录": "Points · Exchange history",
  "停车场 车辆信息": "Parking · Vehicle details",
  "停车场 · 车辆信息": "Parking · Vehicle details",
  "停车场 无车辆": "Parking · No vehicle",
  "停车场 · 无车辆": "Parking · No vehicle",
  "开场": "Opening",
  "起点": "Origin",
  "概念": "Concept",
  "开屏": "Intro",
  "远景": "Far view",
  "近景": "Near view",
  "界面": "Interface",
  "延展": "Extension",
  "演进": "Evolution",
  "后记": "Afterword",
  "会员客服": "Member support",
  "会员社区": "Member community",
  "停车服务": "Parking service",
  "会员积分": "Member points",
  "会员码": "Member code",
};

const FR: Record<string, string> = {
  ...EN,
  "数字街区 · 未来软件猜想": "Quartier numérique · Une vision du logiciel futur",
  "返回作品列表": "Retour aux projets",
  "章节导航": "Navigation des chapitres",
  "数字街区": "Quartier numérique",
  "2023 · 空间化界面实验": "2023 · Expérience d'interface spatiale",
  "从一片街区开始": "Tout commence par un quartier",
  "它的原型，是北京一片由立方体建筑组成的开放式街区。店铺沿街生长，人群在楼宇之间穿行：\"逛\"这件事，本身就是空间里的体验。": "Le point de départ est un quartier ouvert de Pékin, composé de volumes cubiques. Les boutiques bordent les rues et les visiteurs circulent entre les bâtiments. Flâner est déjà une expérience spatiale.",
  "2023 年，一次难得不设限的机会落在我们手里：不必先算成本，不必迁就现成的方案。于是我们决定，把这种在楼宇之间穿行的体验，原样搬进屏幕。": "En 2023, nous avons reçu un brief rare, sans limites imposées. Sans devoir partir du coût ni d'une solution existante, nous avons transposé à l'écran le plaisir de circuler entre les bâtiments.",
  "街区实景 · 白天": "Le quartier de jour",
  "街区实景 · 夜景": "Le quartier de nuit",
  "开放式街区 · 楼宇之间的动线": "Quartier ouvert · Parcours entre les bâtiments",
  "立方体建筑群 · 概念的原点": "Architecture cubique · Origine du concept",
  "建筑 → 体素": "Architecture → voxels",
  "把街区的立方体建筑拆到最小单位，再用色彩、光和呼吸感重新堆起来。熟悉的空间秩序还在，材质和逻辑已经完全是数字的。": "Nous avons réduit l'architecture cubique du quartier à ses plus petites unités, puis nous l'avons reconstruite avec de la couleur, de la lumière et du rythme. L'ordre spatial reste familier, tandis que la matière et la logique deviennent entièrement numériques.",
  "远看是一座城市；走近了，每一块都是一个入口。": "De loin, c'est une ville. De près, chaque bloc devient une entrée.",
  "开屏动画 · 从像素到色彩": "Séquence d'ouverture · Du pixel à la couleur",
  "开屏 · 进化之路": "Ouverture · Une voie d'évolution",
  "按下开屏，画面从黑白像素开始生长，一路快进到色彩鲜明。这是向一款老游戏的致敬，也是项目想说的第一句话：": "L'ouverture naît de pixels monochromes puis accélère jusqu'à la couleur vive. C'est un hommage à un ancien jeu et la première phrase du projet :",
  "设计从像素时代一路进化到今天，而它还想继续向前。双箭头，就是那记快进键。": "Le design a évolué depuis l'ère du pixel et veut encore avancer. La double flèche est sa touche d'avance rapide.",
  "远景 · 一眼看全": "Vue générale · Tout voir d'un regard",
  "站在街区上空，功能一览无余：停车、积分、会员、客服、社区。它们不是列表里的条目，而是挂在建筑上的招牌。": "Au-dessus du quartier, parking, points, adhésion, assistance et communauté apparaissent d'un regard. Ce ne sont plus des éléments de liste, mais des enseignes fixées aux bâtiments.",
  "你不是在\"找功能\"，你是在\"认路\"。": "Vous ne cherchez pas des fonctions. Vous apprenez le lieu.",
  "全局导航 · 一眼看全": "Navigation globale · Tout voir d'un regard",
  "即点即达 · 无需层层进入": "Accès direct · Aucun menu imbriqué",
  "远景 ⇄ 近景 · 一键切换": "Vue générale ⇄ proche · Un seul geste",
  "首页远景 · 动态演示": "Accueil, vue générale · Démonstration",
  "远景 · 实机演示": "Vue générale · Démonstration",
  "首页近景 · 动态演示": "Accueil, vue proche · Démonstration",
  "近景 · 实机演示": "Vue proche · Démonstration",
  "近景 · 走进去": "Vue proche · Entrer dans la ville",
  "视角落下来，城市变成空间。雕塑、悬浮球、楼宇之间的缝隙：功能入口成了可以走近、可以触摸的场景。": "Lorsque le point de vue descend, la ville devient un lieu. Sculptures, formes suspendues et passages entre les bâtiments transforment les fonctions en scènes que l'on peut approcher et toucher.",
  "空间俯冲 · 从俯瞰到置身其中": "Plongée spatiale · Du survol à l'immersion",
  "沉浸交互 · 功能即场景": "Interaction immersive · Les fonctions deviennent des scènes",
  "换一种色彩": "Changer la couleur",
  "就是另一座城": "et découvrir une autre ville",
  "蒙德里安的原色、波普的糖果、星夜的蓝与金、高定的香槟：同一座街区，在不同的艺术语言里醒来。城市不必重建，联名可以一直生长。": "Les primaires de Mondrian, les bonbons pop, le bleu et l'or d'une nuit étoilée, le champagne de la haute couture : le même quartier s'éveille dans différents langages visuels. La ville reste en place et les collaborations continuent de grandir.",
  "滚动切换，或点击下方色卡。": "Faites défiler ou choisissez une palette ci-dessous.",
  "晶体 · 光学玻璃": "Cristal · Verre optique",
  "蒙德里安 · 原色构成": "Mondrian · Composition primaire",
  "波普 · 镜面糖果": "Pop · Bonbon miroir",
  "星夜 · 蓝与金": "Nuit étoilée · Bleu et or",
  "高定 · 金香槟": "Haute couture · Champagne doré",
  "接到现实上": "Relier le projet au réel",
  "把导航接到实景上，路径变成可以看见的东西。体素语言可以一直长下去：新的活动、新的季节、新的联名。": "Reliée au monde réel, la navigation rend le trajet visible. Le langage voxel peut continuer de grandir avec de nouveaux événements, de nouvelles saisons et de nouvelles collaborations.",
  "AR 实景导航": "Navigation en réalité augmentée",
  "持续演进": "Évolution continue",
  "体素语言的持续演进": "Le langage voxel continue d'évoluer",
  "2023 · 后记": "2023 · Postface",
  "一份写给未来的草稿": "Une esquisse adressée au futur",
  "那一年的许多个深夜，办公室的灯一直亮着，笑声也没停过。没有人谈成本，没有人谈边界：我们只是想看看，软件还能长成什么样子。": "Pendant de nombreuses nuits cette année-là, les lumières du bureau sont restées allumées et les rires n'ont pas cessé. Personne ne parlait de coût ni de limites. Nous voulions seulement voir ce que le logiciel pouvait devenir.",
  "后来我常常想起它：想起页面可以是场所，功能可以是风景，想起一群人把天马行空当作日常的那段时间。": "J'y pense encore : des pages devenues lieux, des fonctions devenues paysages, et un groupe de personnes pour qui les idées les plus libres faisaient partie du quotidien.",
  "双箭头的意思是\"快进\"。它至今仍指着前方。": "La double flèche signifie avance rapide. Elle pointe toujours vers l'avant.",
  "回到街区上空 ↑": "Revenir au-dessus du quartier ↑",
  "2023 · 一次不设限的提案 · 一座可以走进去的城市": "2023 · Un brief ouvert · Une ville à parcourir",
  "如果软件不再是一张张页面，而是一座可以走进去的城市，会是什么样子？": "Et si le logiciel cessait d'être une suite de pages pour devenir une ville à parcourir ?",
  "向下滚动，进入街区": "Faites défiler pour entrer dans le quartier",
  "界面落地": "Donner corps à l'interface",
  "概念要能落地才算成立。从首页到会员、积分、停车，每一屏都在同一套体素语言里，该有的效率一点没少。": "Un concept ne vaut que s'il peut être livré. De l'accueil à l'adhésion, aux points et au parking, chaque écran partage le même langage voxel sans perdre en efficacité.",
  "首页 · 远景": "Accueil · Vue générale",
  "首页 · 近景": "Accueil · Vue proche",
  "会员码 · 远景": "Code membre · Vue générale",
  "会员码 · 近景": "Code membre · Vue proche",
  "活动 · 远景": "Événements · Vue générale",
  "活动 · 近景": "Événements · Vue proche",
  "会员中心": "Espace membre",
  "会员信息编辑": "Modifier le profil membre",
  "会员 · 信息编辑": "Membre · Modifier le profil",
  "积分兑换": "Échange de points",
  "积分记录": "Historique des points",
  "积分 · 兑换记录": "Points · Historique des échanges",
  "停车场 车辆信息": "Parking · Informations du véhicule",
  "停车场 · 车辆信息": "Parking · Informations du véhicule",
  "停车场 无车辆": "Parking · Aucun véhicule",
  "停车场 · 无车辆": "Parking · Aucun véhicule",
  "开场": "Ouverture",
  "起点": "Origine",
  "概念": "Concept",
  "开屏": "Introduction",
  "远景": "Vue générale",
  "近景": "Vue proche",
  "界面": "Interface",
  "延展": "Extension",
  "演进": "Évolution",
  "后记": "Postface",
  "会员客服": "Assistance membre",
  "会员社区": "Communauté des membres",
  "停车服务": "Service de stationnement",
  "会员积分": "Points membre",
  "会员码": "Code membre",
};

let activeCopy: Record<string, string> = {};

export function translateTklCopy(value: string) {
  return activeCopy[value] ?? value;
}

export function applyMainSiteLocale(): TklLocale {
  let locale: TklLocale = "zh";
  try {
    const saved = window.localStorage.getItem("creer-locale");
    if (saved === "en" || saved === "fr" || saved === "zh") locale = saved;
  } catch {
    // Storage can be unavailable in privacy-restricted contexts; Chinese remains the fallback.
  }

  activeCopy = locale === "en" ? EN : locale === "fr" ? FR : {};
  document.documentElement.lang = locale === "zh" ? "zh-CN" : locale;
  document.title = translateTklCopy(document.title);

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const textNodes: Text[] = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode as Text);
  for (const node of textNodes) {
    const raw = node.textContent ?? "";
    const key = raw.trim();
    const translated = translateTklCopy(key);
    if (key && translated !== key) node.textContent = raw.replace(key, translated);
  }

  document.querySelectorAll<HTMLElement>("[aria-label], [alt], [data-title]").forEach((el) => {
    for (const attr of ["aria-label", "alt", "data-title"] as const) {
      const value = el.getAttribute(attr);
      if (value) el.setAttribute(attr, translateTklCopy(value));
    }
  });

  return locale;
}
