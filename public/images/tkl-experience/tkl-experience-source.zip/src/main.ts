import "./styles.css";
import gsap from "gsap";
import { Experience } from "./experience/Experience";
import { setupScroll, type ScrollHandle } from "./scroll/chapters";
import {
  applyMainSiteLocale,
  getMainSiteLocale,
  MAIN_SITE_LOCALE_KEY,
  type TklLocale,
} from "./i18n";

/**
 * 入口：Loader（体素双箭头拼合）→ 启动 3D → 绑定滚动 → 播放开场。
 * 无框架依赖；嵌入 Next.js 时调用 mountTKLExperience()，卸载时调用返回的 destroy()。
 */

/** 9×7 网格里组成 ">>" 的格子索引 */
const ARROW_CELLS = [
  [0, 0], [0, 4],
  [1, 1], [1, 5],
  [2, 2], [2, 6],
  [3, 3], [3, 7],
  [4, 2], [4, 6],
  [5, 1], [5, 5],
  [6, 0], [6, 4],
].map(([r, c]) => r * 9 + c);

function buildLoader(): Promise<void> {
  const grid = document.getElementById("loader-logo")!;
  const cells: HTMLElement[] = [];
  for (let i = 0; i < 63; i++) {
    const cell = document.createElement("i");
    if ((i * 7 + 3) % 11 === 0) cell.classList.add("gold");
    grid.appendChild(cell);
    cells.push(cell);
  }
  const arrowCells = ARROW_CELLS.map((i) => cells[i]).filter(Boolean);
  return new Promise((resolve) => {
    gsap
      .timeline({ onComplete: () => resolve() })
      .to(arrowCells, {
        opacity: 1,
        scale: 1,
        duration: 0.32,
        ease: "back.out(2.2)",
        stagger: { each: 0.055, from: "start" },
      })
      .to(".loader-tag", { opacity: 1, duration: 0.4 }, "-=0.4")
      .to({}, { duration: 0.35 });
  });
}

function setupReturnLinkMotion() {
  const link = document.getElementById("return-work");
  const glyph = link?.querySelector<HTMLElement>("span");
  const media = gsap.matchMedia();
  let playIntro = () => {};

  if (!link || !glyph) {
    return { playIntro, destroy: () => media.revert() };
  }

  media.add("(prefers-reduced-motion: reduce)", () => {
    gsap.set(link, { autoAlpha: 1, x: 0, scale: 1 });
    gsap.set(glyph, { x: 0 });
  });

  media.add("(prefers-reduced-motion: no-preference)", () => {
    gsap.set(link, { autoAlpha: 0, x: -12, scale: 0.92 });

    playIntro = () => {
      gsap.to(link, {
        autoAlpha: 1,
        x: 0,
        scale: 1,
        duration: 0.68,
        ease: "power3.out",
        overwrite: "auto",
      });
    };

    const enter = () => {
      gsap.to(link, { scale: 1.035, duration: 0.24, ease: "power3.out", overwrite: "auto" });
      gsap.fromTo(
        glyph,
        { x: 3 },
        { x: -2, duration: 0.42, ease: "power3.out", overwrite: "auto" }
      );
    };
    const leave = () => {
      gsap.to(link, { scale: 1, duration: 0.28, ease: "power3.out", overwrite: "auto" });
      gsap.to(glyph, { x: 0, duration: 0.28, ease: "power3.out", overwrite: "auto" });
    };
    const press = () => {
      gsap.to(link, { scale: 0.96, duration: 0.1, ease: "power1.out", overwrite: "auto" });
      gsap.to(glyph, { x: -4, duration: 0.1, ease: "power1.out", overwrite: "auto" });
    };

    link.addEventListener("pointerenter", enter);
    link.addEventListener("pointerleave", leave);
    link.addEventListener("pointerdown", press);
    link.addEventListener("pointerup", enter);

    return () => {
      link.removeEventListener("pointerenter", enter);
      link.removeEventListener("pointerleave", leave);
      link.removeEventListener("pointerdown", press);
      link.removeEventListener("pointerup", enter);
      gsap.killTweensOf([link, glyph]);
      playIntro = () => {};
    };
  });

  return {
    playIntro: () => playIntro(),
    destroy: () => media.revert(),
  };
}

function setupMainSiteLocaleSync(activeLocale: TklLocale) {
  let reloading = false;
  const sync = () => {
    if (!reloading && getMainSiteLocale() !== activeLocale) {
      reloading = true;
      window.location.reload();
    }
  };
  const onStorage = (event: StorageEvent) => {
    if (event.key === null || event.key === MAIN_SITE_LOCALE_KEY) sync();
  };
  const onVisibility = () => {
    if (!document.hidden) sync();
  };

  window.addEventListener("storage", onStorage);
  window.addEventListener("pageshow", sync);
  document.addEventListener("visibilitychange", onVisibility);

  return () => {
    window.removeEventListener("storage", onStorage);
    window.removeEventListener("pageshow", sync);
    document.removeEventListener("visibilitychange", onVisibility);
  };
}

const waitForPageAssets = async () => {
  const images = Array.from(document.images);
  const videos = Array.from(document.querySelectorAll<HTMLVideoElement>("video"));

  const imageJobs = images.map((img) => {
    img.loading = "eager";
    if (img.complete && img.naturalWidth > 0) return img.decode?.().catch(() => {});
    return new Promise<void>((resolve) => {
      img.addEventListener("load", () => resolve(), { once: true });
      img.addEventListener("error", () => resolve(), { once: true });
    });
  });

  const videoJobs = videos.map((video) => {
    video.pause();
    video.preload = "auto";
    if (video.readyState >= HTMLMediaElement.HAVE_FUTURE_DATA) return Promise.resolve();
    return new Promise<void>((resolve) => {
      video.addEventListener("canplay", () => resolve(), { once: true });
      video.addEventListener("error", () => resolve(), { once: true });
      video.load();
    });
  });

  const assetsReady = Promise.allSettled([...imageJobs, ...videoJobs]);
  const timeout = new Promise<void>((resolve) => window.setTimeout(resolve, 12000));
  await Promise.race([assetsReady, timeout]);
};

/** 隐藏章节里的 autoplay 视频不再持续解码，只播放当前可见章节。 */
const setupVisibleVideoPlayback = () => {
  const videos = Array.from(document.querySelectorAll<HTMLVideoElement>("video[autoplay]"));
  const sync = () => {
    for (const video of videos) {
      const overlay = video.closest<HTMLElement>(".overlay");
      const shouldPlay = !document.hidden && (!overlay || overlay.classList.contains("is-on"));
      if (shouldPlay) video.play().catch(() => {});
      else video.pause();
    }
  };
  const observer = new MutationObserver(sync);
  document.querySelectorAll(".overlay").forEach((overlay) =>
    observer.observe(overlay, { attributes: true, attributeFilter: ["class"] })
  );
  document.addEventListener("visibilitychange", sync);
  sync();
  return () => {
    observer.disconnect();
    document.removeEventListener("visibilitychange", sync);
  };
};

export interface TKLHandle {
  destroy: () => void;
}

export function mountTKLExperience(): TKLHandle {
  const activeLocale = applyMainSiteLocale();
  const stopLocaleSync = setupMainSiteLocaleSync(activeLocale);
  const canvas = document.getElementById("webgl") as HTMLCanvasElement;
  const loaderDone = buildLoader();
  const returnLinkMotion = setupReturnLinkMotion();

  let exp: Experience | null = null;
  let scroll: ScrollHandle | null = null;
  let stopVideoPlayback: (() => void) | null = null;

  try {
    exp = new Experience(canvas);
  } catch (err) {
    console.warn("WebGL 初始化失败，降级为静态展示", err);
    canvas.style.display = "none";
  }

  if (exp) scroll = setupScroll(exp);

  // 字体就绪后再收起 loader，避免标题在开场动画中途重排
  const launchReady = Promise.allSettled([
    document.fonts?.ready,
    loaderDone,
    waitForPageAssets(),
    exp?.ready,
  ]);
  const launchTimeout = new Promise<void>((resolve) => window.setTimeout(resolve, 15000));
  Promise.race([launchReady, launchTimeout]).then(() => {
    document.getElementById("loader")!.classList.add("is-done");
    returnLinkMotion.playIntro();
    stopVideoPlayback = setupVisibleVideoPlayback();
    scroll?.playIntro();
  });

  return {
    destroy() {
      scroll?.destroy();
      exp?.destroy();
      stopVideoPlayback?.();
      returnLinkMotion.destroy();
      stopLocaleSync();
    },
  };
}

// 独立页面直接自启动；作为模块被引入时由宿主调用 mountTKLExperience()
if (!(window as any).__TKL_EMBED__) mountTKLExperience();
