import "./styles.css";
import gsap from "gsap";
import { Experience } from "./experience/Experience";
import { setupScroll, type ScrollHandle } from "./scroll/chapters";

/**
 * 入口：Loader（体素双箭头拼合）→ 启动 3D → 绑定滚动 → 播放开场。
 * 无框架依赖；嵌入 Next.js 时调用 mountTKLExperience()，卸载时调用返回的 destroy()。
 */

/** 9×7 网格里组成 ">>" 的格子索引 */
const ARROW_CELLS = [
  [0, 0], [0, 4],
  [1, 1], [1, 5],
  [2, 2], [2, 6],
  [3, 3], [3, 7],
  [4, 2], [4, 6],
  [5, 1], [5, 5],
  [6, 0], [6, 4],
].map(([r, c]) => r * 9 + c);

function buildLoader(): Promise<void> {
  const grid = document.getElementById("loader-logo")!;
  const cells: HTMLElement[] = [];
  for (let i = 0; i < 63; i++) {
    const cell = document.createElement("i");
    if ((i * 7 + 3) % 11 === 0) cell.classList.add("gold");
    grid.appendChild(cell);
    cells.push(cell);
  }
  const arrowCells = ARROW_CELLS.map((i) => cells[i]).filter(Boolean);
  return new Promise((resolve) => {
    gsap
      .timeline({ onComplete: () => resolve() })
      .to(arrowCells, {
        opacity: 1,
        scale: 1,
        duration: 0.32,
        ease: "back.out(2.2)",
        stagger: { each: 0.055, from: "start" },
      })
      .to(".loader-tag", { opacity: 1, duration: 0.4 }, "-=0.4")
      .to({}, { duration: 0.35 });
  });
}

export interface TKLHandle {
  destroy: () => void;
}

export function mountTKLExperience(): TKLHandle {
  const canvas = document.getElementById("webgl") as HTMLCanvasElement;
  const loaderDone = buildLoader();

  let exp: Experience | null = null;
  let scroll: ScrollHandle | null = null;

  try {
    exp = new Experience(canvas);
  } catch (err) {
    console.warn("WebGL 初始化失败，降级为静态展示", err);
    canvas.style.display = "none";
  }

  if (exp) scroll = setupScroll(exp);

  // 字体就绪后再收起 loader，避免标题在开场动画中途重排
  Promise.allSettled([document.fonts?.ready, loaderDone]).then(() => {
    document.getElementById("loader")!.classList.add("is-done");
    scroll?.playIntro();
  });

  return {
    destroy() {
      scroll?.destroy();
      exp?.destroy();
    },
  };
}

// 独立页面直接自启动；作为模块被引入时由宿主调用 mountTKLExperience()
if (!(window as any).__TKL_EMBED__) mountTKLExperience();
