import { defineConfig } from "vite";

export default defineConfig({
  /**
   * 挂到主站子路径时用 `VITE_BASE=/tkl/ npm run build` 构建，
   * 产物里的资源引用会带上该前缀。默认根目录，本地 dev 不受影响。
   */
  base: process.env.VITE_BASE || "/",
});
